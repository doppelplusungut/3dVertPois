try:
    from BIDS.registration.ridged_intensity.register import (
        register_native_res,
        registrate_nipy,
        apply_registration_nipy,
    )
except Exception as ex:
    # raise ex
    pass
