from __future__ import annotations
import math
import sys
from pathlib import Path
from typing import Literal
from BIDS import load_centroids, Ax_Codes
from BIDS.core.sitk_utils import nii_to_sitk
from BIDS.nii_wrapper import Image_Reference, to_nii


file = Path(__file__).resolve()
from BIDS import Logger_Interface, No_Logger

sys.path.append(str(file.parents[1]))

import numpy as np
import secrets
import nibabel as nib
import SimpleITK as sitk
from BIDS.core.sitk_utils import sitk_to_nii

from BIDS import NII, Centroids, Centroid_Reference, BIDS_FILE, to_nii_interpolateable, Interpolateable_Image_Reference

from dataclasses import dataclass
import warnings

default_axcode_to = ("R", "P", "I")


@dataclass
class Resample_Filter:
    ### Image Resampler
    _resampler: sitk.ResampleImageFilter
    ### Segmentation Resampler
    _resampler_seg: sitk.ResampleImageFilter
    ### Point Reg
    _img_moving: sitk.Image
    _img_fixed: sitk.Image
    _transform: sitk.VersorRigid3DTransform
    orientation: Ax_Codes
    error_reg: float
    error_natural: float
    __crop_buffer = {}

    def transform_points(self, ctd: Centroids, origins_shift2: tuple[slice, ...] | None):
        Move_L = []
        keys = []
        out = {k: value for k, value in zip(keys, Move_L)}

        for key, (x, y, z) in ctd.items():
            ctr_b = self._img_moving.TransformContinuousIndexToPhysicalPoint((x, y, z))
            ctr_b = self._transform.GetInverse().TransformPoint(ctr_b)
            ctr_b = self._img_fixed.TransformPhysicalPointToContinuousIndex(ctr_b)
            out[key] = ctr_b

        return Centroids(
            self.orientation,
            out,
            location=ctd.location,
            zoom=self._img_fixed.GetSpacing(),
            shape=self._img_fixed.GetSize(),
            sorting_list=ctd.sorting_list,
        ).shift_all_centroid_coordinates(origins_shift2)

    def resample(
        self,
        moving_img: Interpolateable_Image_Reference,
        slice: tuple[slice, ...] | bool = False,
    ):
        img_nii = to_nii_interpolateable(moving_img)
        img_sitk = nii_to_sitk(img_nii)
        if img_nii.seg:
            transformed_img: sitk.Image = self._resampler_seg.Execute(img_sitk)
        else:
            transformed_img = self._resampler.Execute(img_sitk)
        if img_nii.seg:
            transformed_img = sitk.Round(transformed_img)
        if isinstance(slice, tuple):
            transformed_img = transformed_img[slice]
        elif slice:
            transformed_img = transformed_img[self.compute_crop()]
        out_nii = sitk_to_nii(transformed_img, seg=img_nii.seg)
        return out_nii

    def compute_crop(self, dist=0):
        """Generates a crop (img[crop]) that cuts both fixed and moving image (after resampling) into the shared used pixel_space.
        Args:
            fixed (Image_Reference): _description_
            moving (Image_Reference): _description_
            resampler (sitk.ResampleImageFilter): _description_
            dist (int, optional): _description_. Defaults to 0.

        Returns:
            crop: _description_
        """
        # if dist in self.__crop_buffer:
        #    return self.__crop_buffer[dist]
        img_sitk = self._img_moving
        transformed_img = self._resampler_seg.Execute(img_sitk)
        # Crop the scans to the registered regions
        ex_slice_f = sitk_to_nii(self._img_fixed, False).compute_crop_slice(dist=dist)
        ex_slice = sitk_to_nii(transformed_img, False).compute_crop_slice(dist=dist, other_crop=ex_slice_f)
        # self.__crop_buffer[dist] = tuple(ex_slice)
        return tuple(ex_slice)


def point_register(
    inter: list[int] | np.ndarray,
    ctd_f_iso: Centroids,
    img_fixed: sitk.Image,
    ctd_m_iso: Centroids,
    img_moving: sitk.Image,
    LABEL_MAX: int,
    verbose=True,
    log: Logger_Interface = No_Logger(),
) -> Resample_Filter:
    assert len(inter) > 2
    # find shared points
    Move_L = []
    Fix_L = []
    # get real world coordinates of the corresponding vertebrae
    for key in inter:
        ctr_mass_b = ctd_m_iso[key % LABEL_MAX : key // LABEL_MAX]
        ctr_b = img_moving.TransformContinuousIndexToPhysicalPoint((ctr_mass_b[0], ctr_mass_b[1], ctr_mass_b[2]))
        Move_L.append(ctr_b)
        ctr_mass_f = ctd_f_iso[key % LABEL_MAX : key // LABEL_MAX]
        ctr_f = img_fixed.TransformContinuousIndexToPhysicalPoint((ctr_mass_f[0], ctr_mass_f[1], ctr_mass_f[2]))
        Fix_L.append(ctr_f)
    log.print("[*] used centroids:", inter, verbose=verbose)
    # Rough registration transform
    moving_image_points_flat = [c for p in Move_L for c in p if not math.isnan(c)]
    fixed_image_points_flat = [c for p in Fix_L for c in p if not math.isnan(c)]
    init_transform = sitk.VersorRigid3DTransform(
        sitk.LandmarkBasedTransformInitializer(sitk.VersorRigid3DTransform(), fixed_image_points_flat, moving_image_points_flat)
    )

    x_old = Fix_L[0]
    y_old = Move_L[0]
    error_reg = 0
    error_natural = 0
    err_count = 0
    err_count_n = 0
    log.print(
        f'{"key": <3}|{"fixed points": <23}|{"moved points after": <23}|{"moved points before": <23}|{"delta fixed/moved": <23}|{"distF": <5}|{"distM": <5}|',
        verbose=verbose,
    )
    k_old = -1000
    for k, x, y in zip(inter, np.round(Fix_L, decimals=1), np.round(Move_L, decimals=1)):
        y2 = init_transform.GetInverse().TransformPoint(y)
        y = [round(m, ndigits=1) for m in y]
        dif = [round(i - j, ndigits=1) for i, j in zip(x, y2)]

        dist = round(math.sqrt(sum([(i - j) ** 2 for i, j in zip(x, x_old)])), ndigits=1)
        dist2 = round(math.sqrt(sum([(i - j) ** 2 for i, j in zip(y, y_old)])), ndigits=1)
        x_ = f"{x[0]:7.1f},{x[1]:7.1f},{x[2]:7.1f}"
        y_ = f"{y[0]:7.1f},{y[1]:7.1f},{y[2]:7.1f}"
        y2_ = f"{y2[0]:7.1f},{y2[1]:7.1f},{y2[2]:7.1f}"
        d_ = f"{dif[0]:7.1f},{dif[1]:7.1f},{dif[2]:7.1f}"
        error_reg += math.sqrt(sum([i * i for i in dif]))
        err_count += 1

        if k - k_old < 50:
            error_natural += abs(dist - dist2)
            err_count_n += 1
        else:
            dist = ""
            dist2 = ""

        log.print(f"{str(k): <3}|{x_: <23}|{y2_: <23}|{y_: <23}|{d_: <23}|{str(dist): <5}|{str(dist2): <5}|", verbose=verbose)

        x_old = x
        y_old = y
        k_old = k

    resampler: sitk.ResampleImageFilter = sitk.ResampleImageFilter()
    resampler.SetReferenceImage(img_fixed)
    resampler.SetDefaultPixelValue(-1050)
    # resampler.SetInterpolator(sitk.sitkNearestNeighbor)
    resampler.SetInterpolator(sitk.sitkBSplineResampler)
    resampler.SetTransform(init_transform)
    resampler_seg = sitk.ResampleImageFilter()
    resampler_seg.SetReferenceImage(img_fixed)
    resampler_seg.SetInterpolator(sitk.sitkNearestNeighbor)
    resampler_seg.SetTransform(init_transform)
    error_reg /= max(err_count, 1)
    error_natural /= max(err_count_n, 1)
    log.print(f"Error avg registration error-vector length: {error_reg: 7.3f}", verbose=verbose)
    log.print(f"Error avg point-distances: {error_natural: 7.3f}", verbose=verbose)
    return Resample_Filter(
        resampler,
        resampler_seg,
        img_moving,
        img_fixed,
        init_transform,
        ctd_f_iso.orientation,
        error_reg,
        error_natural,
    )


if __name__ == "__main__":
    pass
    # a = np.zeros((100, 10, 10))
    # a = nib.Nifti1Image(a, np.eye(4))
    # a = nii_to_sitk(NII(a))
    # img = sitk.GetImageFromArray(np.random.rand(10, 10, 10))
    #
    ## ix = sitk.BSplineTransformInitializer(a, (2, 2, 2), order=3)
    ## sitk.LandmarkBasedTransformInitializer(ix, [(1, 2, 3)], [(2, 3, 4)])
    # ix = sitk.BSplineTransformInitializer(img, (2, 2, 2), order=3)
    ## sitk.LandmarkBasedTransformInitializer(ix, np.array([[1.0, 2.0, 3.0]], dtype=np.float32), np.array([[1.0, 2.0, 3.0]], dtype=np.float32))
    # LandmarkTx = sitk.LandmarkBasedTransformInitializerFilter()
    # ctr_b = [
    #    img.TransformContinuousIndexToPhysicalPoint((1, 2, 2)),
    #    img.TransformContinuousIndexToPhysicalPoint((5, 3, 3)),
    #    img.TransformContinuousIndexToPhysicalPoint((2, 3, 3)),
    #    img.TransformContinuousIndexToPhysicalPoint((9, 1, 1)),
    # ]
    # moving_image_points_flat = [c for p in ctr_b for c in p if not math.isnan(c)]
    # LandmarkTx.SetFixedLandmarks(moving_image_points_flat)
    # LandmarkTx.SetMovingLandmarks(moving_image_points_flat)
    # LandmarkTx.SetBSplineNumberOfControlPoints(4)
    # LandmarkTx.SetReferenceImage(img)
    # InitialTx = LandmarkTx.Execute(ix)
    # print(InitialTx)
