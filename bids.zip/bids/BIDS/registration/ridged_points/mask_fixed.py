from BIDS import NII


def mask_fix_(fixed: NII, moved: NII, ct=True):
    if ct:
        moved = moved + 1000
    f_arr = moved.get_array()
    f_arr[f_arr > 0] = 2
    f_arr[f_arr <= 0] = 0
    infect_list = []

    def infect(x, y, z):
        if any([x < 0, y < 0, z < 0, x == f_arr.shape[0], y == f_arr.shape[1], z == f_arr.shape[2]]):
            return
        if f_arr[x, y, z] == 0:
            f_arr[x, y, z] = 1
            for a, b, c in [
                (1, 0, 0),
                (-1, 0, 0),
                (0, 1, 0),
                (0, -1, 0),
                (0, 1, 0),
                (0, 0, 1),
                (0, 0, -1),
            ]:
                infect_list.append((x + a, y + b, z + c))

        else:
            pass

    infect(0, 0, 0)
    infect(f_arr.shape[0] - 1, 0, 0)
    infect(0, f_arr.shape[1] - 1, 0)
    infect(f_arr.shape[0] - 1, f_arr.shape[1] - 1, 0)

    infect(0, 0, f_arr.shape[2] - 1)
    infect(f_arr.shape[0] - 1, 0, f_arr.shape[2] - 1)
    infect(0, f_arr.shape[1] - 1, f_arr.shape[2] - 1)
    infect(f_arr.shape[0] - 1, f_arr.shape[1] - 1, f_arr.shape[2] - 1)
    while len(infect_list) != 0:
        infect(*infect_list.pop())
    f_arr[f_arr == 0] = 2
    f_arr -= 1
    print(f_arr.sum())
    return fixed.set_array_(f_arr * fixed.get_array())
