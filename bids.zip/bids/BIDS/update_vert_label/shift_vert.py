from __future__ import annotations

from pathlib import Path
import sys

file = Path(__file__).resolve()
sys.path.append(str(file.parents[1]))
sys.path.append(str(file.parents[2]))

import warnings

# TODO whole file deprecated, should be reworked to use centroid in order as list (not next/prev vert)
warnings.warn("This file is deprecated", DeprecationWarning)

import BIDS
from BIDS import bids_files, nii_utils, bids_utils
import numpy as np
import nibabel as nib


def get_shift_map_all(current_labels: list[int, ...] = None, last_t: int = 19, last_l: int = 24, shift: int = 1):
    if current_labels is None:
        current_labels = np.arange(1, 26)
    if 18 in current_labels and 20 in current_labels and last_t not in current_labels:
        print(f"get_shift_map_all with {current_labels}, last_t {last_t}, and shift {shift} doesn't make sense")
        return {}
    return get_shift_map(current_labels=current_labels, last_tl_orig=(last_t, last_l), shift=shift)


def get_shift_map_transition_t(current_labels, last_t, target_t, last_l):
    if last_t == target_t:
        return {}

    t_shift = last_t - target_t
    if t_shift > 2:
        t_shift -= 8
    if t_shift < -2:
        t_shift += 8

    if t_shift < 0:
        shift_pos = nii_utils.get_previous_vert(last_t, last_t, last_l, n_shifts=abs(t_shift))
    else:
        shift_pos = last_t
    return get_shift_map(
        current_labels=current_labels,
        label_range=(shift_pos, 30),
        last_tl_orig=(last_t, last_l),
        target_last_tl=(target_t, last_l),
        shift=t_shift,
    )


def get_shift_map_l1_2_t13(current_labels, last_l):
    return get_shift_map(
        current_labels=current_labels,
        label_range=(28, 30),
        last_tl_orig=(19, last_l),
        target_last_tl=(28, last_l),
        shift=-1,
    )


def get_shift_map_t12_2_l1(current_labels, last_l):
    return get_shift_map(
        current_labels=current_labels,
        label_range=(19, 30),
        last_tl_orig=(19, last_l),
        target_last_tl=(18, last_l),
        shift=1,
    )


def get_shift_map_l1_2_t12(current_labels, last_l):
    return get_shift_map(
        current_labels=current_labels,
        label_range=(20, 30),
        last_tl_orig=(18, last_l),
        target_last_tl=(19, last_l),
        shift=1,
    )


def get_shift_map(
    last_tl_orig: tuple[int, int],
    current_labels: list[int, ...] | None = None,
    label_range: tuple[int, int] = None,
    target_last_tl: tuple[int, int] = None,
    shift: int = 1,
) -> dict:
    """calculates a label_map in interval [label_range[0], label_range[1]]

    Args:
        current_labels: labels in the current data (may be only a subset!)
        label_range: the range of labels that should be shifted (if necessary)
        last_tl_orig: last t and last l index of the sample (eg. annotated T13)
        target_last_tl: the last t and last l index the sample SHOULD have (T13 is not true)
        shift: the number of shifts (positive: vert_idx increase)

    Returns:
        label_map: dict
    """
    if current_labels is None:
        current_labels = np.arange(1, 26)
    elif label_range is None:
        label_range = (min(current_labels), max(current_labels))
    if target_last_tl is None:
        target_last_tl = last_tl_orig

    label_map = {}
    if shift == 0:
        return label_map  # empty dict

    # handle 28 as T13
    if 28 in label_range:
        if label_range[0] == 28:
            nprange = np.arange(20, label_range[1] + 1)
            nprange = np.append(nprange, 28)
        else:
            nprange = np.arange(label_range[0], 20)
            nprange = np.append(nprange, 28)
    else:
        nprange = np.arange(label_range[0], label_range[1] + 1)
    if 20 in nprange and 19 in nprange and 28 not in nprange:
        nprange = np.append(nprange, 28)

    nprange = [x for x in nprange if x in current_labels]  # prone to remove everything not being a vert idx

    for l in nprange:
        if shift > 0:
            label = nii_utils.get_next_vert(l, last_t=target_last_tl[0], last_l=target_last_tl[1], n_shifts=abs(shift))
            if label is None:
                label = nii_utils.get_next_vert(l, last_t=last_tl_orig[0], last_l=last_tl_orig[1], n_shifts=abs(shift))
        else:
            label = nii_utils.get_previous_vert(l, last_t=target_last_tl[0], last_l=target_last_tl[1], n_shifts=abs(shift))
            if label is None:
                label = nii_utils.get_previous_vert(l, last_t=last_tl_orig[0], last_l=last_tl_orig[1], n_shifts=abs(shift))
        label_map[l] = label
    return label_map


def shift_subject(name: str, sample: bids_files.Subject_Container, shift_dict: dict, verbose: bool = False):
    for family in bids_utils.filter_ct_2_family(name, sample, verbose):
        family_key_len = {k: len(v) for k, v in family.items()}
        # print(family_key_len)
        vert_ref, subreg_ref = family["vert"][0], family["subreg"][0]
        # check centroid jsons
        ctd_vert = family.get("ctd_vert", None)
        ctd_subreg = family.get("ctd_subreg", None)
        ctd_arcus = family.get("41", None)
        if ctd_subreg is None or ctd_vert is None:
            # TODO if None calculate
            print(
                f"skipped due to missing json centroid, only got {family_key_len}. Not implemented yet to calculate centroids in this case"
            )
            continue
        if len(ctd_vert) != 1:
            print("not one centroid file!: ", family["ctd_vert"])
            for f in family["ctd_vert"]:
                print(f.file)
            continue
        else:
            ctd_vert = ctd_vert[0]
        # shift mask
        if not vert_ref.has_nii():
            print("vert_ref has no nii, will skip")
            return None
        msk_nii = vert_ref.open_nii()
        shifted_msk_nii = nii_utils.map_labels(msk_nii, label_map=shift_dict)
        nib.save(shifted_msk_nii, vert_ref.get_changed_path(file_type="nii.gz", info={"proc": "shifted"}))

        # shift centroids
        for ctd_list in [ctd_vert, ctd_subreg]:
            if not ctd_list.has_json():
                print("centroid has no json, will skip")
                return None
            shifted_ctd_list = nii_utils.shift_all_centroid_labels(
                ctd_list=nii_utils.load_centroids(ctd_path=ctd_list), label_map=shift_dict
            )
            nii_utils.save_centroids(shifted_ctd_list, out_path=ctd_list.get_changed_path(file_type="json", info={"proc": "shifted"}))


if __name__ == "__main__":
    # current_labels = [6, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24]
    # print("l1_2_t13", get_shift_map_l1_2_t13(current_labels, 24))
    # print("t12_2_l1", get_shift_map_t12_2_l1(current_labels, 25))
    # print("shift +1", get_shift_map_all(current_labels, last_t=28, last_l=24, shift=1))

    shifted = "/home/data/hendrik/transitional_vertebra/data/data_tv_shifted/"
    bids_ds = bids_files.BIDS_Global_info(
        datasets=[shifted], parents=["rawdata", "derivatives", "cutout"], additional_key=["snp", "ovl"], verbose=False
    )

    for name, sample in bids_ds.enumerate_subjects():
        if "fxclass0140" in name:
            break

    from datasets.CT_data import ct_bids_snapshot

    ct_bids_snapshot.snapshot_one_subject(name=name, sample=sample, verbose=True)

    # label_map = get_shift_map_transition_t(current_labels=None, last_t=19, target_t=18, last_l=25)
    # label_map = get_shift_map_all(current_labels=None, last_t=19, last_l=23, shift=-1)
    # print(label_map)

    # shift_subject(name, sample, shift_dict=label_map, verbose=True)
