from enum import Enum, auto


class Log_Type(Enum):
    TEXT = auto()
    NEUTRAL = auto()
    SAVE = auto()
    WARNING = auto()
    WARNING_THROW = auto()
    LOG = auto()
    OK = auto()
    FAIL = auto()
    Yellow = auto()
    STRANGE = auto()
    UNDERLINE = auto()
    ITALICS = auto()
    BOLD = auto()
    DOCKER = auto()
    TOTALSEG = auto()


class bcolors:
    # Front Colors
    BLACK = "\033[30m"
    PINK = "\033[95m"  # Misc
    BLUE = "\033[94m"  # reserved for log-related stuff
    CYAN = "\033[96m"  # save
    GREEN = "\033[92m"  # okay/success
    YELLOW = "\033[93m"  # warnings
    RED = "\033[91m"  # failure, error
    Yellow2 = "\033[33m"  # "\033[33m" <-- Yellow
    GRAY = "\033[37m"
    LightGray = "\033[37m"
    DarkGray = "\033[90m"
    LightRed = "\033[91m"
    LightGreen = "\033[92m"
    LightYellow = "\033[93m"
    LightBlue = "\033[94m"
    LightMagenta = "\033[95m"
    LightCyan = "\033[96m"
    # Modes (unused)
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"
    DISABLE = "\033[02m"
    STRIKETHROUGH = "\033[09m"
    REVERSE = "\033[07m"
    ITALICS = "\033[3m"
    # Background Colors (unused)
    BG_BLACK = "\033[40m"
    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"
    BG_ORANGE = "\033[43m"
    BG_BLUE = "\033[44m"
    BG_PURPLE = "\033[45m"
    BG_CYAN = "\033[46m"
    BG_GRAY = "\033[47m"
    # End of line
    ENDC = "\033[0m"


type2bcolors: dict[Log_Type, tuple[str, str]] = {
    Log_Type.TEXT: (bcolors.ENDC, "[*]"),
    Log_Type.NEUTRAL: (bcolors.ENDC, "[ ]"),
    Log_Type.SAVE: (bcolors.CYAN, "[*]"),
    Log_Type.WARNING: (bcolors.YELLOW, "[?]"),
    Log_Type.WARNING_THROW: (bcolors.YELLOW, "[?]"),
    Log_Type.LOG: (bcolors.BLUE, "[#]"),
    Log_Type.OK: (bcolors.GREEN, "[+]"),
    Log_Type.FAIL: (bcolors.RED, "[!]"),
    Log_Type.Yellow: (bcolors.Yellow2, "[*]"),
    Log_Type.STRANGE: (bcolors.PINK, "[-]"),
    Log_Type.UNDERLINE: (bcolors.UNDERLINE, "[_]"),
    Log_Type.ITALICS: (bcolors.ITALICS, "[ ]"),
    Log_Type.BOLD: (bcolors.BOLD, "[*]"),
    Log_Type.DOCKER: (bcolors.ITALICS, "[Docker]"),
    Log_Type.TOTALSEG: (bcolors.ITALICS, "[TOTALSEG]"),
}


def color_log_text(c: Log_Type, text: str, end: Log_Type = Log_Type.TEXT):
    return color_text(
        color_char=type2bcolors[c][0], text=text, end=type2bcolors[end][0]
    )


def color_text(text: str, color_char, end=bcolors.ENDC):
    return f"{color_char}{text}{bcolors.ENDC}{end}"


def clean_all_color_from_text(text: str):
    import re

    ansi_escape = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")
    text = ansi_escape.sub("", text)
    return text


if __name__ == "__main__":
    text = "Hello World"
    colored_text = color_log_text(Log_Type.OK, text)
    uncolored_text = clean_all_color_from_text(colored_text)
    print(colored_text)
    print(uncolored_text)
