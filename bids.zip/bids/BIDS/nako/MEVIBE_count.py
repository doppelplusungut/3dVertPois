from BIDS.bids_files import BIDS_FILE, BIDS_Global_info, Subject_Container
import nibabel as nib
from pathlib import Path
import pandas as pd
import numpy as np

nako_path = "/media/data/new_NAKO/NAKO/MRT/"

global_info = BIDS_Global_info([nako_path], ["rawdata", "derivatives"])

l = []
count = []

fix_rotation_nako = True
sub_with_out = 0
normal_size = 0

for subj_name, subject in global_info.enumerate_subjects():
    subject: Subject_Container
    query = subject.new_query(flatten=True)
    # It must exist a dixon and a msk
    query.filter("format", "t1dixon")
    query.filter("rec", "water")
    bids_files = list(query.loop_list())
    if len(bids_files) == 4:
        normal_size += 1
        continue
    if len(bids_files) == 0:
        sub_with_out += 1
        continue
    l.append(subj_name)
    count.append(len(bids_files))


n = [i for i in range(20)] + ["" for i in count[20:]]
c = ["" for i in count]
c[0] = str(sub_with_out)
c[4] = str(normal_size)
count_np = np.array(count)
for i in np.unique(count_np):
    c[i] = str(np.count_nonzero(count_np == i))
empty = ["" for i in count]
df = pd.DataFrame.from_dict({"sub": l, "count": count, "": empty, "n": n, "count of n": c})
df.to_excel("BIDS/nako/MEVIBE_count.xlsx", header=True, index=False)
