import sys
from pathlib import Path

file = Path(__file__).resolve()
sys.path.append(str(file.parents[1]))
sys.path.append(str(file.parents[2]))
from BIDS.snapshot2D import create_snapshot, Snapshot_Frame, Visualization_Type, Image_Modes
from BIDS import BIDS_Global_info, calc_centroids_labeled_buffered, Location

from IPython.display import Image

# Warning: This file loops over a hole dataset and makes snapshots
dataset = Path("/media/data/new_NAKO/NAKO/MRT/")

bids_global_object = BIDS_Global_info([dataset], ["rawdata"], additional_key=["sequ", "seg", "ovl", "e"], verbose=True, clear=True)
# First loop: Loop over subjects
for subject_name, subject_container in bids_global_object.enumerate_subjects(sort=True):
    t2_query = subject_container.new_query(flatten=True)
    # t2_query.filter('format','T2w')
    # dixon_query.flatten()
    t2_query.filter("Filetype", "backup")
    # now we can loop over the CT files.
    regions = {}
    for t2w in t2_query.loop_list():
        print(t2w)
        # c = t2w.get('chunk')
        out_file1 = t2w.get_changed_path("jpg", format="snapshot", parent="rawdata", make_parent=False)
        # regions[c] = t2w
        frames = [Snapshot_Frame(t2w, mode="MRI")]  # without centroids
        out_file2 = t2w.dataset / "rawdata_low_quality_ds" / "snapshots_fixed_T2w_rotation" / out_file1.name
        out_file2.parent.mkdir(exist_ok=True)
        create_snapshot([out_file2], frames)
