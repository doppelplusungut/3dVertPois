"""This file fixes all T2w combined images, by inverting the array and coping the affine. 
Set the nako_path
Make a test run with:
fix_rotation_nako = False

this will create the excel table.

fix_rotation_nako = True 
will override the T2w images. A back up is made. Rename the ..._T2w.backup to ..._T2w.nii.gz to retrieve them if necessary.
"""
from BIDS.bids_files import BIDS_FILE, BIDS_Global_info, Subject_Container
import nibabel as nib
from pathlib import Path
import numpy as np

nako_path = "/media/data/new_NAKO/NAKO/MRT/"
fix_rotation_nako = False

global_info = BIDS_Global_info([nako_path], ["rawdata", "derivatives"])

l = []
count = 0
# These files don't work with the fix
skip_list = [
    # "100083",
    "100266",  # reason: Black screen...
    "101900",  # reason: Flipped differently
    # "102330",
    # "102765",
    # "102916",
    # "104264",
    # "104448",
    # "104613",
    # "104889",
    # "106020",
    # "106095",
    # "108310",
    # "108914",
    # "109083",
    # "110666",
    # "111025",
    # "111273",
]
# These files have strange markings.
strange_symbol = [
    "100419",
    "100598",
    "101290",
    "102020",
    "102179",
    "102227",
    "102583",
    "103205",
    "103304",
    "104103",
    "104971",
    "105162",
    "106440",
    "108560",
    "109809",
    "110072",
    "110529",
    "111007",
]
for subj_name, subject in global_info.enumerate_subjects():
    subject: Subject_Container
    query = subject.new_query(flatten=True)
    # It must exist a dixon and a msk
    query.filter("format", "T2w")
    query.filter_non_existence("chunk", lambda _: True)

    for bids_file in query.loop_list():

        nii = bids_file.open_nii().nii
        a = nii.affine
        count += 1
        if any([a[0, 0] == 1, a[1, 1] == 1, a[2, 2] == 1]):
            print(bids_file.info["sub"], nii.shape)
            l.append(bids_file.info["sub"])

            if fix_rotation_nako:
                f_nii = str(bids_file.file["nii.gz"])
                backup_name = f_nii.replace("_T2w.nii.gz", "_T2w.backup")
                # if Path(backup_name).exists():
                #    Path(f_nii).unlink()
                #    Path(backup_name).rename(f_nii)
                p = Path(f_nii)
                pgl = p.parent.glob(p.name.split("sequ", maxsplit=1)[0] + "chunk-HWS_sequ-*_T2w.nii.gz")
                f_nii_ref = next(pgl)
                assert Path(f_nii_ref).exists()
                nii_ref: nib.Nifti1Image = nib.load(f_nii_ref)
                data = nii.get_fdata().copy()[:, ::-1]
                if "101900" == subj_name:
                    data = data[:, ::-1]
                Path(f_nii).rename(backup_name)
                nib.save(nib.Nifti1Image(data, nii_ref.affine, nii_ref.header), f_nii)

            # exit()
if not fix_rotation_nako:
    import pandas as pd

    print(len(l) / count)
    df = pd.DataFrame.from_dict({"sub": l})
    df.to_excel("T2_combined_false_rotation.xlsx", header=True, index=False)
