import glob
import numpy as np
from torch.utils.data import Dataset
from math import floor, ceil
import os
from BIDS import NII, BIDS_Family, BIDS_FILE, Ax_Codes, Zooms


class nii_Datasets(Dataset):
    def __init__(
        self,
        families: list[BIDS_Family],
        keys=["ct"],
        axcodes_to: Ax_Codes | None = None,
        zoom: Zooms = (-1, -1, -1),
        _transform=None,
        force_unique=True,
    ):
        self.families = families
        self.keys = keys
        self._transform = _transform
        self.axcodes_to = axcodes_to
        self.zoom = zoom
        self.force_unique = force_unique

    def __getitem__(self, index):
        return nii_Dataset_slice(
            self.families[index],
            self.keys,
            axcodes_to=self.axcodes_to,
            zoom=self.zoom,
            _transform=self._transform,
            force_unique=self.force_unique,
        )

    def __len__(self):
        return len(self.families)


class nii_Dataset_slice(Dataset):
    def __init__(
        self,
        fam: BIDS_Family,
        keys=["ct"],
        axcodes_to: Ax_Codes | None = None,
        zoom: Zooms = (-1, -1, -1),
        _transform=None,
        force_unique=True,
    ):
        self.family = fam
        for k in keys:
            if k not in fam:
                raise ValueError(f"Expected that '{k}' in family.\n {fam}")
        if force_unique:
            for k, f in fam.items():
                if k in keys and len(f) != 1:
                    raise ValueError(f"Expected only on file for key '{k}' in family.\n {fam}")

        self._transform = _transform
        self.keys = keys
        self._nii_data: None | dict[str, np.ndarray] = None
        self.axcodes_to = axcodes_to
        self.zoom = zoom

    @property
    def nii_data(self) -> dict[str, np.ndarray]:
        return self.load()

    def load(self):
        if self._nii_data is None:
            self._nii_data = {}
            shape = None
            for key, file in self.family.items():
                file = file[0]
                arr = file.open_nii_reorient(axcodes_to=self.axcodes_to).rescale_(self.zoom).get_array()
                if shape is not None:
                    assert shape == arr.shape
                shape = arr.shape
                self._nii_data[key] = arr
        return self._nii_data

    def get_copy(self):
        return self.nii_data.copy()

    def __getitem__(self, index):
        if self._transform is not None:
            return (self._transform(self.nii_data[key][index]) for key in self.keys)
        return self.nii_data[index]

    def __len__(self):
        return self.nii_data[self.keys[0]].shape[0]

    def __str__(self) -> str:
        return f"Nii_dataset: \n file = {self.family}\n axis = {self.axcodes_to}\n shape = {self.zoom}"
