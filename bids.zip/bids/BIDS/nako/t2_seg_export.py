import json
from pathlib import Path
import zipfile
import os
import sys

file = Path(__file__).resolve()
sys.path.append(str(file.parents[1]))
from bids_utils import run_cmd
import nibabel as nib

"""
This file can extract stacked dicom from siemens files.
The json are beyond repair... I extract the information from a other folder instead of the json. THIS IS RELAY JANKY.
"""


def main(folder, sequ):
    program_path = "/media/robert/Expansion/NAKO/dicom2nifti_malek/dcm2niix"
    dcm_dir = f"/media/robert/Expansion/NAKO/MRT/{folder}/"

    nifti_dir = f"/media/data/NAKO/MRT/{folder}/"
    same_dir = "/media/data/NAKO/MRT/III_T2_TSE_SAG_LWS/"  # Die

    Path(nifti_dir).mkdir(exist_ok=True)
    Path(nifti_dir).mkdir(exist_ok=True)

    zip_dir = "/tmp"
    i = 0
    for path in Path(dcm_dir).iterdir():
        if not path.name.endswith(".zip"):
            continue
        try:
            with zipfile.ZipFile(path, "r") as zip_ref:
                out_path = os.path.join(zip_dir, os.path.basename(path)[:-4])
                zip_ref.extractall(out_path)
        except:
            "Failed to zip"
            pass

        nd = Path(nifti_dir, path.name[:9])
        sd = Path(same_dir, path.name[:9])
        print(sd)
        while True:
            if sd.is_dir():
                nd.mkdir(exist_ok=True)
                sd = next(sd.iterdir())
                nd2 = nd
                nd = Path(nd, sd.name.replace("json", "nii.gz"))
                print(nd)
            else:
                break

        cmd = [program_path, "-o", nd2, "y", out_path]
        run_cmd(cmd, nd2)

        for path in Path(nd2).iterdir():
            if path.name.endswith(".json"):
                pass
            else:
                nib.save(nib.load(str(path)), str(nd).replace("sequ-31", sequ))
            path.unlink()
        i += 1
        print(out_path)
        import shutil

        shutil.rmtree(out_path)
        # Path(out_path).rmdir()
        # if i == 5:
        #    break
        print()


folder = "Sag T2 Spine"
sequ = "sequ-t2"
main(folder, sequ)
folder = "3D_GRE_TRA_W_COMPOSED"
sequ = "sequ-w"
main(folder, sequ)
# unzip "/media/robert/Expansion/NAKO/MRT/Sag T2 Spine/104871_30_Sag T2 Spine.zip" -d /tmp/name
# /105345_30/Sag T2 Spine/1.3.12.2.1107.5.2.19.45659.2015110315140118767707544
#
# /-o "/media/data/pohl/NAKO/MRT/Sag T2 Spine/{sub}/ses-{ses}/sub-100002_30_ses-20160704_sequ-31_mr.nii.gz" --progress y  /media/data/pohl/NAKO/MRT/T2_tmp
