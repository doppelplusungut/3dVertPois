"""
This file renames all nako files from the exported names to the new names names. Set "base_path"

consider "include_session"
"""

import os
import sys
from pathlib import Path

file = Path(__file__).resolve()
sys.path.append(str(file.parents[1]))
from BIDS.bids_files import BIDS_FILE


base_path = "/media/data/new_NAKO/NAKO/MRT/"
include_session = False


def move_file(old_f, new_f):
    old_f = Path(str(old_f).replace("json", "nii.gz"))
    new_f = Path(str(new_f).replace("json", "nii.gz"))

    old_f_j = Path(str(old_f).replace("nii.gz", "json"))
    new_f_j = Path(str(new_f).replace("nii.gz", "json"))
    print(new_f, new_f_j)
    # assert not new_f.exists()
    assert not new_f_j.exists(), new_f_j
    if old_f.exists():
        old_f.rename(new_f)
    if old_f_j.exists():
        old_f_j.rename(new_f_j)
    for path in old_f.parents:
        path = str(path)
        if len(os.listdir(path)) == 0 and os.path.isdir(path):
            os.rmdir(path)


folders = [
    "3D_GRE_TRA_F",
    "3D_GRE_TRA_in",
    "3D_GRE_TRA_opp",
    "3D_GRE_TRA_W",
    "Sag T2 Spine",
    "Sag_T2_Spine",
    "III_T2_TSE_SAG_LWS",
    "II_T2_TSE_SAG_BWS",
    "I_T2_TSE_SAG_HWS",
    "ME_vibe_fatquant_pre_Eco0_OPP1",
    "ME_vibe_fatquant_pre_Eco1_PIP1",
    "ME_vibe_fatquant_pre_Eco2_OPP2",
    "ME_vibe_fatquant_pre_Eco3_IN1",
    "ME_vibe_fatquant_pre_Eco4_POP1",
    "ME_vibe_fatquant_pre_Eco5_ARB1",
    "ME_vibe_fatquant_pre_Output_F",
    "ME_vibe_fatquant_pre_Output_FP",
    "ME_vibe_fatquant_pre_Output_R2s_Eff",
    "ME_vibe_fatquant_pre_Output_W",
    "ME_vibe_fatquant_pre_Output_WP",
    "PD_FS_SPC_COR",
]
folders = [
    "3D_GRE_TRA_F",
    "3D_GRE_TRA_in",
    "3D_GRE_TRA_opp",
    "3D_GRE_TRA_W",
    "Sag T2 Spine",
    "Sag_T2_Spine",
    "III_T2_TSE_SAG_LWS",
    "II_T2_TSE_SAG_BWS",
    "I_T2_TSE_SAG_HWS",
    "ME_vibe_fatquant_pre_Eco0_OPP1",
    "ME_vibe_fatquant_pre_Eco1_PIP1",
    "ME_vibe_fatquant_pre_Eco2_OPP2",
    "ME_vibe_fatquant_pre_Eco3_IN1",
    "ME_vibe_fatquant_pre_Eco4_POP1",
    "ME_vibe_fatquant_pre_Eco5_ARB1",
    "ME_vibe_fatquant_pre_Output_F",
    "ME_vibe_fatquant_pre_Output_FP",
    "ME_vibe_fatquant_pre_Output_R2s_Eff",
    "ME_vibe_fatquant_pre_Output_W",
    "ME_vibe_fatquant_pre_Output_WP",
    "PD_FS_SPC_COR",
]

names2rec = {
    "3D_GRE_TRA_F": "fat",
    "3D_GRE_TRA_in": "in",
    "3D_GRE_TRA_opp": "opp",
    "3D_GRE_TRA_W": "water",
    # "Sag T2 Spine": "full",
    # "III_T2_TSE_SAG_LWS": "LWS",
    # "II_T2_TSE_SAG_BWS": "BWS",
    # "I_T2_TSE_SAG_HWS": "HWS",
    "ME_vibe_fatquant_pre_Eco0_OPP1": "eco0-opp1",
    "ME_vibe_fatquant_pre_Eco1_PIP1": "eco1-pip1",
    "ME_vibe_fatquant_pre_Eco2_OPP2": "eco2-opp2",
    "ME_vibe_fatquant_pre_Eco3_IN1": "eco3-in1",
    "ME_vibe_fatquant_pre_Eco4_POP1": "eco4-pop1",
    "ME_vibe_fatquant_pre_Eco5_ARB1": "eco5-arb1",
    "ME_vibe_fatquant_pre_Output_F": "fat",
    "ME_vibe_fatquant_pre_Output_FP": "fat-phase",
    "ME_vibe_fatquant_pre_Output_R2s_Eff": "r2s",
    "ME_vibe_fatquant_pre_Output_W": "water",
    "ME_vibe_fatquant_pre_Output_WP": "water-phase",
    # "PD_FS_SPC_COR": "",
}
names2acq = {
    "3D_GRE_TRA": "ax",
    "Sag T2 Spine": "sag",
    "Sag_T2_Spine": "sag",
    "III_T2_TSE_SAG_LWS": "sag",
    "II_T2_TSE_SAG_BWS": "sag",
    "I_T2_TSE_SAG_HWS": "sag",
    "ME_vibe_fatquant_pre_": "ax",
    "PD_FS_SPC_COR": "iso",
}
names2format = {
    "3D_GRE_TRA": "t1dixon",
    "Sag T2 Spine": "T2w",
    "Sag_T2_Spine": "T2w",
    "III_T2_TSE_SAG_LWS": "T2w",
    "II_T2_TSE_SAG_BWS": "T2w",
    "I_T2_TSE_SAG_HWS": "T2w",
    "ME_vibe_fatquant_pre_": "mevibe",
    "PD_FS_SPC_COR": "pd",
}
format2subfolder = {
    "t1dixon": "/t1dixon",
    "mevibe": "/mevibe",
    "T2w": "/T2w",
    "pd": "/pd",
}
hasSequ = [
    "Sag T2 Spine",
    "Sag_T2_Spine",
    "III_T2_TSE_SAG_LWS",
    "II_T2_TSE_SAG_BWS",
    "I_T2_TSE_SAG_HWS",
    "ME_vibe_fatquant_pre_Eco0_OPP1",
    "ME_vibe_fatquant_pre_Eco1_PIP1",
    "ME_vibe_fatquant_pre_Eco2_OPP2",
    "ME_vibe_fatquant_pre_Eco3_IN1",
    "ME_vibe_fatquant_pre_Eco4_POP1",
    "ME_vibe_fatquant_pre_Eco5_ARB1",
    "ME_vibe_fatquant_pre_Output_F",
    "ME_vibe_fatquant_pre_Output_FP",
    "ME_vibe_fatquant_pre_Output_R2s_Eff",
    "ME_vibe_fatquant_pre_Output_W",
    "ME_vibe_fatquant_pre_Output_WP",
    "PD_FS_SPC_COR",
]
acq_name_keys = list(names2acq.keys())
names2chunk = {
    "III_T2_TSE_SAG_LWS": "LWS",
    "II_T2_TSE_SAG_BWS": "BWS",
    "I_T2_TSE_SAG_HWS": "HWS",
}


for foldername in folders:
    print(foldername)
    if not Path(base_path, foldername).exists():
        continue
    for __subject in Path(base_path, foldername).iterdir():
        move_list = []
        subject_name = __subject.name
        if subject_name in ["106203_25.nii", "104898_25.nii", "106350_25.nii"]:
            continue
        for __session in __subject.iterdir():

            for __files in __session.iterdir():
                if str(__files).endswith(".json"):
                    continue
                print("in", str(__files))

                # foldername = "3D_GRE_TRA_F"
                file = BIDS_FILE(
                    str(__files),
                    base_path,
                    verbose=False,
                )
                info = {"sub": subject_name.split("_")[0]}
                # If the session level is omitted in the folder structure, the filename MUST begin with the string sub-<label>, without ses-<label>
                if include_session:
                    info["ses"] = file.info["ses"]
                format = None
                for f in acq_name_keys:
                    if f in foldername:
                        info["acq"] = names2acq[f]
                        format = names2format[f]
                        break
                assert format is not None
                if foldername in names2rec:
                    info["rec"] = names2rec[foldername]
                if foldername in names2chunk:
                    info["chunk"] = names2chunk[foldername]
                if foldername.startswith("3D_GRE_TRA"):
                    slice_location = {}
                    for i in range(1, 100):
                        file_name = file.get_changed_path(file_type="json", info={"sequ": i, "sub": subject_name}, parent=foldername)
                        # print(file_name, Path(file_name).exists())
                        if Path(file_name).exists():
                            slice_location[i] = BIDS_FILE(file_name, base_path, verbose=False).open_json()["SliceLocation"]
                            # TODO Currently I assume that all images are rotated the same
                        else:
                            pass
                            break
                    a = [k for k, v in sorted(slice_location.items(), key=lambda item: -item[1])]
                    # print(a, file.get("sequ"))
                    try:
                        info["chunk"] = str(a.index(int(file.get("sequ", "0"))) + 1)  # type: ignore
                    except Exception:
                        info["chunk"] = "1"
                if foldername in hasSequ:
                    if file.info["sequ"] == "t2":
                        file.info["sequ"] = "1"
                    info["sequ"] = file.info["sequ"]
                # del file.info["sequ"]
                file.info = info

                subfolder = ""
                if format in format2subfolder:
                    subfolder = format2subfolder[format]
                else:
                    subfolder = "/anat"
                if include_session:
                    subfolder = "ses-{ses}" + subfolder
                new_name = file.get_changed_path(
                    file_type="nii.gz",
                    format=format,
                    parent="rawdata",
                    path=subject_name[:3] + "/sub-{sub}" + subfolder,
                    from_info=True,
                    # info={"run": 1} if foldername in hasRun else None,
                    # auto_add_run_id=True,
                )

                print("out", new_name)
                if "3D_GRE_TRA" in foldername:
                    move_list.append((__files, Path(new_name)))
                else:
                    move_file(__files, new_name)

        # print(move_list)
        for old_f, new_f in move_list:
            move_file(old_f, new_f)


# find 3D_GRE_TRA_F -type f | wc -l
# find 3D_GRE_TRA_in -type f | wc -l
# find 3D_GRE_TRA_opp -type f | wc -l
# find 3D_GRE_TRA_W -type f | wc -l
# find Sag_T2_Spine -type f | wc -l
# find III_T2_TSE_SAG_LWS -type f | wc -l
# find II_T2_TSE_SAG_BWS -type f | wc -l
# find I_T2_TSE_SAG_HWS -type f | wc -l
# find ME_vibe_fatquant_pre_Eco0_OPP1 -type f | wc -l
# find ME_vibe_fatquant_pre_Eco1_PIP1 -type f | wc -l
# find ME_vibe_fatquant_pre_Eco2_OPP2 -type f | wc -l
# find ME_vibe_fatquant_pre_Eco3_IN1 -type f | wc -l
# find ME_vibe_fatquant_pre_Eco4_POP1 -type f | wc -l
# find ME_vibe_fatquant_pre_Eco5_ARB1 -type f | wc -l
# find ME_vibe_fatquant_pre_Output_F -type f | wc -l
# find ME_vibe_fatquant_pre_Output_FP -type f | wc -l
# find ME_vibe_fatquant_pre_Output_R2s_Eff -type f | wc -l
# find ME_vibe_fatquant_pre_Output_W -type f | wc -l
# find ME_vibe_fatquant_pre_Output_WP -type f | wc -l
# find PD_FS_SPC_COR -type f | wc -l
