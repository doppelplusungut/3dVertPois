### NAKO Dataset 

The [NAKO Dataset](https://d-nb.info/1236778871/34) is a national cohort study with multiple MRI sequences.

The data for t1-dixon is a full body scan and are numbered. The numbering has no meaning. We reorder the numbering from top to bottom by reading the Z value from the json. The values are multiplied by -1 by the orientation. The index will be stored in chunk-tag and are unrelated to the sequ-tag. The sequ-tag of this file will be discarded.

This study is big and opening folders with 10000 folders leads to issues, like long load times. We introduce sub-folders for the first three digits, so a folder has no more than 1000 subjects. The session is a bijection to the subject, so we omit them from the file/folder structure. It can be retrieved from the json with the "AcquisitionDate"-key.

We keep the value of the sequ-tag (excluding t1-dixon). They are used to identify file families of duplicates in mevibe. To prevent errors we do not relabel them. (TODO analyze if these can be renamed... when there is only one file pressed the sequ numbers don't match.) The sequ-tag is currently inconsistent, especially when multiple files are present. We are currently unable to fully automatically decide if a file belongs to the same sequence, especially for ME_vibe. More knowledge is needed. The numbers in the example below are the most common ones. They are incorrect, in our opinion, they are from the same acquisition and are mutually exclusive, so they should have the same sequ-number. A sequence should only be different if it's a copy, and/or a different reconstruction, or a different acquisition.

The subject names are incompatible with BIDS and the _30 will be removed. This number has no relevant information and the original name can be retrieved in the json file with the key "PatientID".
example: 123456_30 --> 123456

The t1dixon and the mevibe files are numerous. They are split from the default anat folder into two separate folders "t1dixon" and "mevibe". Having those (usually) 22/32 folders separate should decrease searching time. This may be not 100% BIDS-compliant. 

We can not export the combined images. We can export the combined T2w, but without a json and the affine is sometimes broken. We fixed 608 of the rotation automatically. Please report any error you find in the files. Currently, we list them in this file.

See https://bids-specification.readthedocs.io/en/stable/appendices/entities.html.

![Types](../../docs/NAKO_MRI_types.png)

#### Raw Dataset Structure

The current, raw database is not structured in a 100% BIDS-compliant way, as depicted in this example:


```
...
── 3D_GRE_TRA_F			
│   ├── 123456_30
│   │   ├── ses-20001230
│   │   │   ├── sub-123456_30_ses-20001231_sequ-1_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-1_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-2_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-2_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-3_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-3_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-4_mr.json
│   │   │   └── sub-123456_30_ses-20001231_sequ-4_mr.nii.gz
── 3D_GRE_TRA_in
│   ├── 123456_30
│   │   ├── ses-20001230
│   │   │   ├── sub-123456_30_ses-20001231_sequ-1_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-1_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-2_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-2_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-3_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-3_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-4_mr.json
│   │   │   └── sub-123456_30_ses-20001231_sequ-4_mr.nii.gz
── 3D_GRE_TRA_opp
│   ├── 123456_30
│   │   ├── ses-20001230
│   │   │   ├── sub-123456_30_ses-20001231_sequ-1_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-1_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-2_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-2_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-3_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-3_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-4_mr.json
│   │   │   └── sub-123456_30_ses-20001231_sequ-4_mr.nii.gz			
── 3D_GRE_TRA_W		
│   ├── 123456_30
│   │   ├── ses-20001230
│   │   │   ├── sub-123456_30_ses-20001231_sequ-1_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-1_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-2_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-2_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-3_mr.json
│   │   │   ├── sub-123456_30_ses-20001231_sequ-3_mr.nii.gz
│   │   │   ├── sub-123456_30_ses-20001231_sequ-4_mr.json
│   │   │   └── sub-123456_30_ses-20001231_sequ-4_mr.nii.gz	
── III_T2_TSE_SAG_LWS	
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-31_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-31_mr.nii.gz
── II_T2_TSE_SAG_BWS		
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-2406_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-2406_mr.nii.gz
── I_T2_TSE_SAG_HWS		
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-29_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-29_mr.nii.gz
── ME_vibe_fatquant_pre_Eco0_OPP1	
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-53_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-53_mr.nii.gz
── ME_vibe_fatquant_pre_Eco1_PIP1	
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-54_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-54_mr.nii.gz
── ME_vibe_fatquant_pre_Eco2_OPP2	
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-55_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-55_mr.nii.gz
── ME_vibe_fatquant_pre_Eco3_IN1
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-56_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-56_mr.nii.gz
── ME_vibe_fatquant_pre_Eco4_POP1
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-57_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-57_mr.nii.gz
── ME_vibe_fatquant_pre_Eco5_ARB1
│   ├── 123456_30
│   │   ├── ses-20001231	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-58_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-58_mr.nii.gz
── ME_vibe_fatquant_pre_Output_W
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-59_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-59_mr.nii.gz
── ME_vibe_fatquant_pre_Output_FP
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-60_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-60_mr.nii.gz
── ME_vibe_fatquant_pre_Output_F
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-61_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-61_mr.nii.gz
── ME_vibe_fatquant_pre_Output_WPopp1_run
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-62_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-62_mr.nii.gz
── ME_vibe_fatquant_pre_Output_R2s_Eff
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-63_mr.json  
│   │   │   └── sub-123456_30_ses-20001231_sequ-63_mr.nii.gz
── PD_FS_SPC_COR
│   ├── 123456_30
│   │   ├── ses-20001230	
│   │   │   ├── sub-123456_30_ses-20001231_sequ-17_pd.json
│   │   │   └── sub-123456_30_ses-20001231_sequ-17_pd.nii.gz
```


The newly generated, mostly BIDS compliant database adheres to the following structure:

```
rawdata
│   ├──122
...
│   ├──123
...
│   │   ├── sub-123455
...
│   │   ├── sub-123456
│   │   │   ├── mevibe
│   │   │   │   ├── sub-123456_acq-ax_rec-eco0-opp1_sequ-53_mevibe.json
│   │   │   │   ├── sub-123456_acq-ax_rec-eco0-opp1_sequ-53_mevibe.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-eco1-pip1_sequ-54_mevibe.json
│   │   │   │   ├── sub-123456_acq-ax_rec-eco1-pip1_sequ-54_mevibe.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-eco2-opp2_sequ-55_mevibe.json
│   │   │   │   ├── sub-123456_acq-ax_rec-eco2-opp2_sequ-55_mevibe.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-eco3-in1_sequ-56_mevibe.json
│   │   │   │   ├── sub-123456_acq-ax_rec-eco3-in1_sequ-56_mevibe.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-eco4-pop1_sequ-57_mevibe.json
│   │   │   │   ├── sub-123456_acq-ax_rec-eco4-pop1_sequ-57_mevibe.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-eco5-arb1_sequ-58_mevibe.json
│   │   │   │   ├── sub-123456_acq-ax_rec-eco5-arb1_sequ-58_mevibe.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-fat-phase_sequ-60_mevibe.json
│   │   │   │   ├── sub-123456_acq-ax_rec-fat-phase_sequ-60_mevibe.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-fat_sequ-63_mevibe.json
│   │   │   │   ├── sub-123456_acq-ax_rec-fat_sequ-63_mevibe.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-r2s_sequ-61_mevibe.json
│   │   │   │   ├── sub-123456_acq-ax_rec-r2s_sequ-61_mevibe.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-water-phase_sequ-62_mevibe.json
│   │   │   │   ├── sub-123456_acq-ax_rec-water-phase_sequ-62_mevibe.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-water_sequ-59_mevibe.json
│   │   │   │   └── sub-123456_acq-ax_rec-water_sequ-59_mevibe.nii.gz
│   │   │   ├── t1dixon
│   │   │   │   ├── sub-123456_acq-ax_rec-fat_chunk-1_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-fat_chunk-1_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-fat_chunk-2_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-fat_chunk-2_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-fat_chunk-3_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-fat_chunk-3_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-fat_chunk-4_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-fat_chunk-4_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-in_chunk-1_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-in_chunk-1_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-in_chunk-2_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-in_chunk-2_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-in_chunk-3_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-in_chunk-3_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-in_chunk-4_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-in_chunk-4_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-opp_chunk-1_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-opp_chunk-1_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-opp_chunk-2_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-opp_chunk-2_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-opp_chunk-3_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-opp_chunk-3_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-opp_chunk-4_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-opp_chunk-4_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-water_chunk-1_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-water_chunk-1_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-water_chunk-2_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-water_chunk-2_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-water_chunk-3_t1dixon.json
│   │   │   │   ├── sub-123456_acq-ax_rec-water_chunk-3_t1dixon.nii.gz
│   │   │   │   ├── sub-123456_acq-ax_rec-water_chunk-4_t1dixon.json
│   │   │   │   └── sub-123456_acq-ax_rec-water_chunk-4_t1dixon.nii.gz
│   │   │   ├── pd
│   │   │   |   ├── sub-123456_acq-iso_sequ-17_pd.json
│   │   │   |   └── sub-123456_acq-iso_sequ-17_pd.nii.gz
│   │   │   └── T2
│   │   │       ├── sub-123456_acq-iso_sequ-17_pd.json
│   │   │       ├── sub-123456_acq-iso_sequ-17_pd.nii.gz
│   │   │       ├── sub-123456_acq-sag_chunk-BWS_sequ-2406_T2w.json
│   │   │       ├── sub-123456_acq-sag_chunk-BWS_sequ-2406_T2w.nii.gz
│   │   │       ├── sub-123456_acq-sag_chunk-HWS_sequ-29_T2w.json
│   │   │       ├── sub-123456_acq-sag_chunk-HWS_sequ-29_T2w.nii.gz
│   │   │       ├── sub-123456_acq-sag_chunk-LWS_sequ-31_T2w.json
│   │   │       ├── sub-123456_acq-sag_chunk-LWS_sequ-31_T2w.nii.gz
│   │   │       └── sub-123456_acq-sag_sequ-1_T2w.nii.gz
│   │   ├── sub-123457
...
│   ├──124
...
```

# NAKO Overview

[Paper](d-nb.info/1236778871/34)

Tag: aqu

| Key | Meaning   | Description                   |
| --- | --------- | ----------------------------- |
| sag | sagittal  | Primary acquisition direction |
| ax  | axial     | Primary acquisition direction |
| iso | isometric | 3D equidistant acquisition    |
|     |           |                               |

## 3D_GRE_TRA
See Figure 6 A,B

T1-weighted 3D volumetric interpolated breath-hold examination (VIBE) image from the neck to the knees with coronal reconstructed images. 

Tag: rec (mod: t1dixon)

| Key   | Meaning      | Description |
| ----- | ------------ | ----------- |
| in    | in-phase     | T1-like     |
| opp   | out-of-phase |             |
| fat   | fat          | Body fat    |
| water | water        | Body water  |
|       |              |             |

- (W_COMPOSED) a unification of the images (BROKEN! We can only extract one modalities. Don't use this. If you want stitched data, use the stitching modulus. )

New Path
```python
f"{sub[:3]}/sub-{sub}/t1dixon/sub-{sub}_acq-{"ax"}_rec-{"fat","in","opp","water"}_chunk-{index}_t1dixon.json"
```
Known issues:
- A small fraction has more than 4 images.
- There are 7 that have only 1 image in the dataset.
- There are 7 that have only 2 image in the dataset.
- There are 1 that have only 3 image in the dataset.
- 103322 has multiple acquisitions. They are now mixed...

## ME_vibe_fatquant_pre_Eco*
3D
See Figure 6 C,D
multi echo VIBE images with six echoes yield percentage-scaled fat (C) and
R2eff (D) images of the liver

Tag: rec (mod: mevibe)

| Key         | Meaning | Description               |
| ----------- | ------- | ------------------------- |
| eco0_OPP1   |         | Input from Spin-echo      |
| eco1_PIP1   |         | Input from Spin-echo      |
| eco2_OPP2   |         | Input from Spin-echo      |
| eco3_IN1    |         | Input from Spin-echo      |
| eco4_POP1   |         | Input from Spin-echo      |
| eco5_ARB1   |         | Input from Spin-echo      |
| fat         | fat     | Body fat                  |
| fat-phase   |         | Body fat - Phase signal   |
| r2s         |         | relation time R2*         |
| water       | water   | Body water                |
| water-phase |         | Body phase - Phase signal |
|             |         |                           |


New Path
```python
#Input
f"{sub[:3]}/sub-{sub}/mevibe/sub-{sub}_acq-{"ax"}_rec-{"eco0-opp1","eco1-pip1","eco2-opp2","eco3-in1","eco4-pop1","eco5-arb1",}_sequ-{index}_mevibe.json"
#Output
f"{sub[:3]}/sub-{sub}/mevibe/sub-{sub}_acq-{"ax"}_rec-{"fat","fat-phase","r2s","water-phase","water"}_sequ-{index}_mevibe.json"
```
## PD_FS_SPC_COR
PD: Protonden density

From the Paper:

Musculoskeletal imaging. Musculoskeletal imaging will focus on the two major disease entities of osteoarthrosis (degenerative joint diease) and inflammatory joint disease. The protocol includes an established fat-suppressed 1-mm isotropic spatial-resolution 3D fast spin-echo with variable flip angle contrast proton-density sequence of the pelvis to assess the most relevant phenotypic parameters of osteoarthrosis and inflammatory joint disease. In addition to cartilage and labrum condition, potential osteophytes or subcondral cysts as markers of osteoarthrosis and emoroacetabular impingement can be assessed. Moreover, parameters for inflammatory joint disease, such as synovitis, joint effusion, articular bone marrow edema, and bursitis, will be imaged, and potential adjacent myopathies or tendinopathies can be visualized. Additionally, bone marrow lesions of the pelvic skeleton can be appreciated. Furthermore, the sacrum and the sacroiliac joints will be covered by the 3D fast spin-echo sequence so that signs of sacroiliitis will be detected. In addition, a two-dimensional T2-weighted fast spin-echo sequence of the entire spine will enable visualization and assessment of disc egeneration and disc herniations (protrusion, extrusion, sequestration). Moreover, possible osteochondrosis, spondylosis, osteoporosis with potential vertebral fractures, overall vertebral shape and potential endplate changes, spinal canal stenosis, and bone marrow changes in the examined participants will be appreciated. The MR protocol for musculoskeletal imaging overlaps anatomically in part with the protocol for thoracoabdominal imaging and therefore can extend the research foci; an example is the 1-mm isotropic 3D fast spin-echo sequence in the pelvis, which allows precise volumetric measurement of the prostate and its enlargement (47)


```python
f"{sub[:3]}/sub-{sub}/mevibe/sub-{sub}_acq-{"iso"}_sequ-{index}_pd.json"
```

## T2_TSE_SAG
SAGITAL

See Figure 7: A) T2-weighted MR image of the thorax and abdomen obtained as part of the body protocol. B, C, MR images obtained as part of the musculoskeletal protocol (PD with fat saturation of the pelvis [B] and T2-weighted image of the entire spine [C] )

Tag: chunk 

| Key     | Meaning           | Description    |
| ------- | ----------------- | -------------- |
| HWS     | Halswirbelsäule   | cervical spine |
| BWS     | Brustwirbelsäule  | thoracic spine |
| LWS     | Lendenwirbelsäule | lumbar spine   |
| !No Key |                   | the 3 combined |
|         |                   |                |

- No Key: Combination of all images (Export BROKEN. We could only get the nii.gz. See LWS/BWS/HWS for meta data...)

Known issues:

The Combined image may be rotated false. You can detect them by the affine matrix. 

Example: 

103067:
two HWS images. "sequ-2" bad quality.

Upside down:
- sub-100005-30_acq-sag_sequ-1_T2w.nii.gz
- 110811_30

The Combined images have no meta data.

100127_30 json:  "PatientSize": 0.0, 

Failed Names; The name TAGs are different:
- 104898_25
- 106203_25
- 106350_25
This folders are empty:
- 105345_30
- 106194_20
- 106594_30

Note: We fixed the rotation of 608 Images in the T2w combined images. A backup is under "sub-*_acq-sag_sequ-1_T2w.backup". A List of subjects is under T2_combined_false_rotation.xlsx


```python
f"{sub[:3]}/sub-{sub}/mevibe/sub-{sub}_acq-{"iso"}_chunk-{"BWS","HWS","LWS",None}_sequ-{index}_pd.json"
# None means the key is missing
```
TODO Sag_T2_Spine:
Bei Number:
- 104898_25
- 106203_25
- 106350_25
ist die Ordnerstruktur nicht richtig. Bei diesen Patienten sind die Niftis direkt gespeichert ohne diese Strukte 'Patientid/ses_YYYYMMDD/____________.ni.gz'
Ich lege die Ordner mit session 00000000 an, damit cih sie in die List aufnehmen kann.

### Borken ZIP
gzip.BadGzipFile Unnamed: 0                                                          527
PatientID                                                        109574
Split                                                              test
Bin                                                                   8
PatientSex                                                            F
PatientAge                                                           45
PatientSize                                                        1.76
PatientWeight                                                      71.0
InstitutionAddress                                             Mannheim
LWS                   /media/data/pohl/NAKO/MRT/III_T2_TSE_SAG_LWS/1...
BWS                   /media/data/pohl/NAKO/MRT/II_T2_TSE_SAG_BWS/10...
HWS                   /media/data/pohl/NAKO/MRT/I_T2_TSE_SAG_HWS/109...
Name: 527, dtype: object

