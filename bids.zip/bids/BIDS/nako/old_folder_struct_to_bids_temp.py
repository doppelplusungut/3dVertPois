from glob import glob
import os
import sys
from pathlib import Path

file = Path(__file__).resolve()
sys.path.append(str(file.parents[1]))
from bids_files import BIDS_Global_info, BIDS_FILE, strict_mode

ses_dic = {}

for file in glob("/media/data/NAKO/MRT/rawdata/*/sub-*/*.nii.gz"):

    bf = BIDS_FILE(file, "/media/data/NAKO/MRT/rawdata")

    # if bf.get("sub") in ses_dic:
    #    assert bf.get("ses") == ses_dic[bf.get("sub")]
    # else:
    #    ses_dic[bf.get("sub")] = bf.get("ses")

    parent = Path(file).parent
    name = Path(file).name
    if name.endswith("t1dixon.nii.gz"):
        continue
    if "run-t2" in name:

        a, b = name.split("run-", maxsplit=1)
        b, c = b.split("_", maxsplit=1)
        if b != "t2":
            print(b)
            continue
        b = 1
        target_path = Path(parent, f"{a}run-{b}_{c}")
        if target_path.exists():
            continue
        Path(file).rename(target_path)
        # Path(parent, name.replace("nii.gz", "json")).rename(Path(parent, f"{a}run-{b}_{c}".replace("nii.gz", "json")))

    # out = Path(parent, b)
    # print(b)
