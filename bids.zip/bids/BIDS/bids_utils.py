from __future__ import annotations
from pathlib import Path
import subprocess
import sys
import os

file = Path(__file__).resolve()
sys.path.append(str(file.parents[1]))

import typing
from BIDS import BIDS_FILE, Subject_Container, BIDS_Family
import warnings

warnings.warn("deprecated", DeprecationWarning)


###################
# Find and sort into ct, vert, subreg, ctd_vert, ctd_subreg, and ctd_arcus
###################
def key_transform(bf: BIDS_FILE):
    if "seg" not in bf.info:
        return None
    if "CUSTOM" == bf.info["seg"]:
        return "ctd_" + "vert"
    if bf.format == "ctd" and "label" not in bf.info:
        return "ctd_" + bf.info["seg"]
    return None


def filter_ct_2_family(name: str, sample: Subject_Container, verbose: bool = False) -> None | typing.Iterator[BIDS_Family]:
    """Runs a filter with custom key_transform, the result being a family with ct, vert, subreg as nii, and ctd_vert, ctd_subreg and ctd_arcus... as centroid references

    Args:
        name: name of the subject
        sample: subject container
        verbose:

    Returns:
        q.loop_dict(key_transform=key_transform)
    """
    if name == "unsorted":
        seq = sample.sequences[""]
        print(f"skipped because it is unsorted, from path {seq[0].file}") if verbose else None
        return None
    q = sample.new_query()
    q.flatten()
    q.filter(key="filetype", filter_fun=lambda x: x == "nii.gz" or x == "json")
    q.unflatten()
    q.filter(key="format", filter_fun="ct")
    return q.loop_dict()


###################
# Misc
###################


def extract_nii(d: dict[str, BIDS_FILE]) -> tuple[list[BIDS_FILE], list[str]]:
    """loops over a dictionary and returns two lists.

    Args:
        d (dict[str, BIDS_FILE]): A dictionary the is usually produced by Searchquery.loop() or Subject_Container.get_sequence_files()

    Returns:
        tuple[list[BIDS_FILE], list[str]]: The first list contains all BIDS_FILE that contain a nii.gz. The seconde is a unique key.
    """
    out = []
    keys = []
    for k, v in d.items():
        if isinstance(v, list):
            for i, l in enumerate(v):
                if "nii.gz" in l.file:
                    out.append(l)
                    keys.append(f"{k}_{i}")
        elif "nii.gz" in v.file:
            out.append(v)
            keys.append(k)
    return out, keys


import time


def run_cmd(cmd_ex: list[str], ouf_file: Path | None = None, print_ignore_list: list[str] = [], verbose=True) -> int:
    """Runs the command in the list

    Args:
        cmd_ex (list[str]): Command line argument. Instead of whitespaces us a list to separate tokens. All whitespaces must be removed or they will be part of the Token.
        ouf_file (Path, optional): Prints '[#] Saved to {ouf_file}', if given. Defaults to None.

    Returns:
        int: Error-Code
    """

    process = subprocess.Popen(cmd_ex, stdout=subprocess.PIPE, universal_newlines=True)

    while True:
        assert process.stdout is not None
        output = process.stdout.readline()
        if output != "":
            print("[S]", output.strip()) if verbose else None
        # Do something else
        return_code = process.poll()
        if return_code is not None:
            # Process has finished, read rest of the output
            for output in process.stdout.readlines():
                time.sleep(0.001)
                __do_print(output.strip(), print_ignore_list) if verbose else None
            print(f"[#] RETURN CODE", return_code) if verbose else None
            if ouf_file is not None:
                print(f"[#] Saved to {str(ouf_file)}") if verbose else None
            break
    return return_code


def __do_print(output: str, print_ignore_list: list[str]):
    output = output.strip()
    if len(output) <= 1:
        return
    for key in print_ignore_list:
        if key in output:
            print("[S]", output, end="\r")
    print("[S]", output)


def run_docker(folder_name: Path|str, print_ignore_list: list[str] = [], verbose=True):
    # docker run -v /media/data/NAKO/MRT/test/new_docker2/result_paper_T2_pix2pix/rawdata/:/data christianpayer/verse19 /predict.sh --user 1000

    # docker run --user $UID -v /media/data/robert/test/MRSpineSeg_ours/result_paper_T1_pix2pix_sa-unet/:/data anjanys/bonescreen-segmentor:main /src/process_spine.py
    code = run_cmd(
        cmd_ex=[
            "docker",
            "run",
            "--user",  # Make files with the same user
            str(os.getuid()),  # Use $UID for console
            "-v",
            f"{folder_name}:/data",
            "anjanys/bonescreen-segmentor:main",
            "/src/process_spine.py",
        ],
        print_ignore_list=print_ignore_list,
        verbose=verbose,
    )
    return code
    # remove Docker:
    # docker images
    # docker rmi $dockerid" -f
