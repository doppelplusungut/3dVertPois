from dataclasses import dataclass, field

from pathlib import Path
import numpy as np
import nibabel as nib
import nibabel.processing as nip
import nibabel.orientations as nio
from scipy.ndimage import center_of_mass
import json

from typing import Any, Type, TypedDict, Union, Tuple, List, TypeVar, TypeGuard, overload
from typing_extensions import Self, override
import BIDS.bids_files
from BIDS.nii_wrapper import to_nii, to_nii_optional, NII, Image_Reference
import warnings
from BIDS.vert_constants import *

from functools import partial

_Point3D = TypedDict("Point3D", X=float, Y=float, Z=float, label=int)
_Orientation = TypedDict("Orientation", direction=Tuple[str, str, str])
_Centroid_DictList = list[Union[_Orientation, _Point3D]]
from typing_extensions import Self

C = TypeVar("C", bound="POI")
POI_ID = Tuple[int, int] | slice

Centroid_Reference = Union[BIDS.bids_files.BIDS_FILE, Path, str, Tuple[Image_Reference, Image_Reference, list[int]], C]


ctd_info_blacklist = ["zoom", "shape", "direction", "format", "rotation", "origin"]  # "location"


def unpack_poi_id(key: POI_ID):
    if isinstance(key, int) or isinstance(key, np.integer):
        region = int(key % LABEL_MAX)
        subregion = int(key // LABEL_MAX)
    elif isinstance(key, slice):
        region = key.start
        subregion = key.stop
    else:
        region, subregion = key
    return region, subregion


class Abstract_POI_Definition:
    def __init__(
        self, path: str | Path | None = None, region: dict[int, str] | None = None, subregion: dict[int, str] | None = None
    ) -> None:
        if path is not None:
            with open(path) as f:
                info = json.load(f)
                region = info["region"]
                subregion = info["subregion"]
        assert region is not None
        assert subregion is not None
        assert max(region.keys()) <= 256
        assert max(subregion.keys()) <= 256

        self.region_idx2name = region
        self.region_name2idx = {value: key for key, value in region.items()}
        self.subregion_idx2name = subregion
        self.subregion_name2idx = {value: key for key, value in subregion.items()}


class Sentinel:
    pass


class POI_Descriptor:
    #
    def __init__(
        self, *, default: POI_Dict | None = None, definition=Abstract_POI_Definition(region=v_idx2name, subregion=subreg_idx2name)
    ):
        if default is None:
            default = {}
        self.pois = default
        self.definition = definition
        self.flatten = False
        self._len: int | None = None

    def __set_name__(self, owner, name):
        self._name = "_" + name

    def __get__(self, obj, type):
        if obj is None:
            return self.pois

        return getattr(obj, self._name, self.pois)

    def __set__(self, obj, value):
        self._len = None
        setattr(obj, self._name, int(value))

    def copy(self):
        from copy import deepcopy

        return POI_Descriptor(default=deepcopy(self.pois))

    def sort(self: Self, inplace=True, natural_numbers=False, sorting_list=None):
        """Sort vertebra dictionary by sorting_list"""
        if natural_numbers:
            poi_new = dict(sorted(self.pois.items()))
            for k, v_dict in poi_new.items():
                poi_new[k] = dict(sorted(v_dict.items()))
        elif sorting_list is None:
            return self
        else:
            poi_new = dict(sorted(self.pois.items(), key=partial(order_vert_name, v_idx_order=sorting_list)))
            for k, v_dict in poi_new.items():
                poi_new[k] = dict(sorted(v_dict.items(), key=partial(order_vert_name, v_idx_order=sorting_list)))
        if inplace:
            self.pois = poi_new
        return poi_new

    def items(self):
        self.sort()
        i = 0
        for region, sub in self.pois.items():
            for subregion, coords in sub.items():
                i += 1
                yield region, subregion, coords
        self._len = i

    def apply_all(self, fun: Callable[[float, float, float], Coordinate], inplace=False):
        if inplace:
            out = self
        else:
            out = POI_Descriptor()
        for region, subregion, cord in self.items():
            out[region:subregion] = fun(*cord)
        return out

    def values(self):
        return list(y for x1, x2, y in self.items())

    def keys(self):
        return list((x1, x2) for x1, x2, y in self.items())

    def keys_region(self):
        return list(self.pois.keys())

    def keys_subregion(self):
        return set(x2 for x1, x2, y in self.items())

    def __getitem__(self, key: POI_ID) -> Coordinate:
        region, subregion = unpack_poi_id(key)
        return self.pois[int(region)][int(subregion)]

    def __setitem__(self, key: POI_ID, value: Coordinate):
        self._len = None
        region, subregion = unpack_poi_id(key)
        if region not in self.pois:
            self.pois[region] = {}
        self.pois[int(region)][int(subregion)] = tuple(value)

    def __contains__(self, key: POI_ID) -> bool:
        assert not isinstance(key, int), f"Must be a (vert,subreg) or vert:subreg not {key}"
        region, subregion = unpack_poi_id(key)
        if region in self.pois:
            return subregion in self.pois[region]
        else:
            return False

    def str_to_int(self, key: str, subregion: bool):
        try:
            return self.definition.subregion_name2idx[key] if subregion else self.definition.region_name2idx[key]
        except Exception as e:
            try:
                return int(key)
            except Exception as ex:
                pass
            log.print(
                f"{key} is not in ",
                self.definition.subregion_name2idx if subregion else self.definition.region_name2idx,
                subregion,
                type=log_file.Log_Type.FAIL,
            )
            raise e

    def str_to_int_list(self, *keys: int | str, subregion=False):
        out: list[int] = []
        for k in keys:
            if isinstance(k, str):
                k = self.str_to_int(k, subregion)
            out.append(k)
        return out

    def str_to_int_dict(self, d: dict[int | str, int | str] | dict[int, int], subregion=False):
        out: dict[int, int] = {}
        for k, v in d.items():
            if isinstance(k, str):
                k = self.str_to_int(k, subregion)
            if isinstance(v, str):
                v = self.str_to_int(v, subregion)
            out[k] = v
        return out

    def __str__(self) -> str:
        return str(self.pois)

    def __repr__(self) -> str:
        return str(self.pois)

    def __eq__(self, x):
        if isinstance(x, POI_Descriptor):
            return x.pois == self.pois
        if isinstance(x, dict):
            return self.normalize_input_data(x).pois == self.pois
        return False

    def __len__(self) -> int:
        if self._len == None:
            self._len = len(list(self.items()))
        return self._len

    @classmethod
    def normalize_input_data(cls, dic: dict):
        _centroids = cls()
        for k, v in dic.items():
            if isinstance(k, (tuple, list)) and isinstance(v, (tuple, list)) and len(v) == 3:
                _centroids[k[0], k[1]] = tuple(v)  # type: ignore
            elif isinstance(k, (int, float)) and isinstance(v, tuple) and len(v) == 3:
                _centroids[0, int(k)] = v  # type: ignore
            elif isinstance(v, dict):
                for k2, v in v.items():
                    _centroids[int(k), int(k2)] = v
            else:
                raise ValueError(dic, type(dic))
        return _centroids

    def pop(self, key: POI_ID, default):
        region, subregion = unpack_poi_id(key)
        if region not in self.pois:
            return default
        subregs = self.pois[region]
        out = subregs.pop(subregion, default)
        if len(subregs) == 0:
            self.pois.pop(region)
        return out


@dataclass
class Abstract_POI:
    _centroids: POI_Descriptor = field(default_factory=lambda: POI_Descriptor(), repr=False, kw_only=True)
    centroids: POI_Descriptor = field(repr=False, hash=False, compare=False, default=None)  # type: ignore

    @property
    def centroids(self) -> POI_Descriptor:
        return self._centroids  # type: ignore

    @centroids.setter
    def centroids(self, value):
        if isinstance(value, property):
            return
        if isinstance(value, POI_Descriptor):
            self._centroids = value
        elif isinstance(value, dict):
            self._centroids = POI_Descriptor.normalize_input_data(value)
        else:
            raise ValueError(value, type(value))

    def _get_centroids(self) -> POI_Descriptor:
        return self.centroids  # type: ignore

    def apply_all(self, fun: Callable[[float, float, float], Coordinate], inplace=False):
        return self._get_centroids().apply_all(fun, inplace)

    @property
    def is_global(self) -> bool:
        ...

    # map_labels
    # _map_labels
    # save
    # sort
    # __itter__
    # __contains__
    # __getitem__
    # __getitem__
    # __setitem__
    # len
    # items/keys/values
    # remove_centroid_
    # round
    # filter_by_ids
    # load


ROUNDING_LVL = 7


@dataclass
class POI(Abstract_POI):
    """
    This class represents a collection of centroids used to define points of interest in medical imaging data.

    Attributes:
        orientation (Ax_Codes): A tuple of three string values representing the orientation of the image.
        centroids (dict): A dictionary of centroid points, where the keys are the labels for the centroid
            points, and values are tuples of three float values representing the x, y, and z coordinates
            of the centroid.
        zoom (Zooms | None): A tuple of three float values representing the zoom level of the image.
            Defaults to None if not provided.
        shape (tuple[float, float, float] | None): A tuple of three integer values representing the shape of the image.
            Defaults to None if not provided.
        sorting_list (List[int] | None): A list of integer values representing the order of the centroid points.
            Defaults to None if not provided.
        format (int | None): An integer value representing the format of the image. Defaults to None if not provided.
        info (dict): Additional information stored as key-value pairs. Defaults to an empty dictionary.
        rotation (Rotation | None): A 3x3 numpy array representing the rotation matrix for the image orientation.
            Defaults to None if not provided.
        origin (Coordinate | None): A tuple of three float values representing the origin of the image in millimeters
            along the x, y, and z axes. Defaults to None if not provided.

    Properties:
        is_global (bool): Property indicating whether the POI is a global POI. Always returns False.
        zoom (Zooms | None): Property getter for the zoom level.
        affine: Property representing the affine transformation for the image.

    Examples:
        >>> # Create a POI object with 2D dictionary input
        >>> from BIDS.core.poi import POI
        >>> poi_data = {
        ...     (1, 0): (10.0, 20.0, 30.0),
        ...     (2, 1): (15.0, 25.0, 35.0),
        ... }
        >>> poi_obj = POI(centroids=poi_data, orientation=("R", "A", "S"), zoom=(1.0, 1.0, 1.0),
        ...               shape=(256, 256, 100))

        >>> # Access attributes
        >>> print(poi_obj.orientation)
        ('R', 'A', 'S')
        >>> print(poi_obj.centroids)
        {1: {0: (10.0, 20.0, 30.0)}, 2: {1: (15.0, 25.0, 35.0)}}
        >>> print(poi_obj.zoom)
        (1.0, 1.0, 1.0)
        >>> print(poi_obj.shape)
        (256, 256, 100)

        >>> # Update attributes
        >>> poi_obj.rescale_((2.0, 2.0, 2.0))
        >>> poi_obj.centroids[(3, 0)] = (5.0, 15.0, 25.0)
        >>> print(poi_obj)
        POI(centroids={1: {0: (5.0, 10.0, 15.0)}, 2: {1: (7.5, 12.5, 17.5)}, 3: {0: (5.0, 15.0, 25.0)}}, orientation=('R', 'A', 'S'), zoom=(2.0, 2.0, 2.0), info={}, origin=None)

        >>> # Create a copy of the object
        >>> poi_copy = poi_obj.copy()

        >>> # Perform operations
        >>> poi_obj = poi_obj.map_labels({(1): (4), (2): (4)})
        >>> poi_obj.round_(0)
        >>> print(poi_obj)
        POI(centroids={4: {0: (5.0, 10.0, 15.0), 1: (8.0, 12.0, 18.0)}, 3: {0: (5.0, 15.0, 25.0)}}, orientation=('R', 'A', 'S'), zoom=(2.0, 2.0, 2.0), info={}, origin=None)
    """

    orientation: Ax_Codes = ("R", "A", "S")
    zoom: None | Zooms = field(init=True, default=None)  # type: ignore
    shape: tuple[float, float, float] | None = field(default=None, repr=False, compare=False)
    sorting_list: List[int] | None = field(default=None, repr=False, compare=False)
    format: int | None = field(default=None, repr=False, compare=False)
    info: dict = field(default_factory=dict, compare=False)  # additional info (key,value pairs)
    rotation: Rotation | None = field(default=None, repr=False, compare=False)
    origin: Coordinate | None = None
    # internal
    _zoom: None | Zooms = field(init=False, default=None, repr=False, compare=False)

    @property
    def is_global(self):
        return False

    @property
    def zoom(self):
        return self._zoom

    @property
    def affine(self):
        assert self.zoom is not None, "Attribute 'zoom' must be set before calling affine."
        assert self.rotation is not None, "Attribute 'rotation' must be set before calling affine."
        assert self.origin is not None, "Attribute 'origin' must be set before calling affine."
        aff = np.eye(4)
        aff[:3, :3] = self.rotation @ np.diag(self.zoom)
        aff[:3, 3] = self.origin
        return np.round(aff, ROUNDING_LVL)

    @zoom.setter
    def zoom(self, value):
        if isinstance(value, property):
            pass
        elif value is None:
            self._zoom = None
        else:
            self._zoom = tuple(round(float(v), ROUNDING_LVL) for v in value)

    def clone(self, **qargs):
        return self.copy(**qargs)

    def _extract_affine(self):
        return {"zoom": self.zoom, "origin": self.origin, "shape": self.shape, "rotation": self.rotation}

    def copy(
        self,
        centroids: POI_Dict | POI_Descriptor | None = None,
        orientation: Ax_Codes | None = None,
        zoom: Zooms | None | Sentinel = Sentinel(),
        shape: tuple[float, float, float] | None | Sentinel = Sentinel(),
        rotation: Rotation | None | Sentinel = Sentinel(),
        origin: Coordinate | None | Sentinel = Sentinel(),
    ) -> Self:
        """Create a copy of the POI object with optional attribute overrides.

        Args:
            centroids (POI_Dict | POI_Descriptor | None, optional): The centroids to use in the copied object.
                Defaults to None, in which case the original centroids will be used.
            orientation (Ax_Codes | None, optional): The orientation code to use in the copied object.
                Defaults to None, in which case the original orientation will be used.
            zoom (Zooms | None | Sentinel, optional): The zoom values to use in the copied object.
                Defaults to Sentinel(), in which case the original zoom values will be used.
            shape (tuple[float, float, float] | None | Sentinel, optional): The shape values to use in the copied object.
                Defaults to Sentinel(), in which case the original shape values will be used.
            rotation (Rotation | None | Sentinel, optional): The rotation matrix to use in the copied object.
                Defaults to Sentinel(), in which case the original rotation matrix will be used.
            origin (Coordinate | None | Sentinel, optional): The origin coordinates to use in the copied object.
                Defaults to Sentinel(), in which case the original origin coordinates will be used.
        Returns:
            POI: A new POI object with the specified attribute overrides.

        Examples:
            >>> centroid_obj = POI(...)
            >>> centroid_obj_copy = centroid_obj.copy(zoom=(2.0, 2.0, 2.0), rotation=rotation_matrix)
        """
        if isinstance(shape, tuple):
            shape = tuple(round(float(v), 7) for v in shape)
        return POI(
            centroids=centroids if centroids is not None else self.centroids,
            orientation=orientation if orientation is not None else self.orientation,
            zoom=zoom if not isinstance(zoom, Sentinel) else self.zoom,
            shape=shape if not isinstance(shape, Sentinel) else self.shape,
            rotation=rotation if not isinstance(rotation, Sentinel) else self.rotation,
            origin=origin if not isinstance(origin, Sentinel) else self.origin,
            sorting_list=self.sorting_list,
            info=self.info,
            format=self.format,
        )

    def local_to_global(self, x: Coordinate | list[float]):
        """Converts local coordinates to global coordinates using zoom, rotation, and origin.

        Args:
            x (Coordinate | list[float]): The local coordinate(s) to convert.

        Returns:
            Coordinate: The converted global coordinate(s).

        Raises:
            AssertionError: If the attributes 'zoom', 'rotation', or 'origin' are missing.

        Notes:
            The 'zoom' and 'rotation' attributes should be set before calling this method.

        Examples:
            >>> centroid_obj = Centroids(...)
            >>> centroid_obj.zoom = (2.0, 2.0, 2.0)
            >>> centroid_obj.rotation = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
            >>> centroid_obj.origin = (10.0, 20.0, 30.0)
            >>> local_coordinate = (1.0, 2.0, 3.0)
            >>> global_coordinate = centroid_obj.local_to_global(local_coordinate)
        """
        assert self.zoom is not None, "Attribute 'zoom' must be set before calling local_to_global."
        assert self.rotation is not None, "Attribute 'rotation' must be set before calling local_to_global."
        assert self.origin is not None, "Attribute 'origin' must be set before calling local_to_global."

        a = self.rotation @ np.array(x) * np.array(self.zoom) + self.origin
        # return tuple(a.tolist())
        return tuple(round(float(v), ROUNDING_LVL) for v in a)

    def global_to_local(self, x: Coordinate | list[float]) -> Coordinate:
        """Converts global coordinates to local coordinates using zoom, rotation, and origin.

        Args:
            x (Coordinate | list[float]): The global coordinate(s) to convert.

        Returns:
            Coordinate: The converted local coordinate(s).

        Raises:
            AssertionError: If the attributes 'zoom', 'rotation', or 'origin' are missing.

        Notes:
            The 'zoom' and 'rotation' attributes should be set before calling this method.

        Examples:
            >>> centroid_obj = Centroids(...)
            >>> centroid_obj.zoom = (2.0, 2.0, 2.0)
            >>> centroid_obj.rotation = np.array([[1, 0, 0], [0, 1, 0], [0, 0, 1]])
            >>> centroid_obj.origin = (10.0, 20.0, 30.0)
            >>> global_coordinate = (20.0, 30.0, 40.0)
            >>> local_coordinate = centroid_obj.global_to_local(global_coordinate)
        """
        assert self.zoom is not None, "Attribute 'zoom' must be set before calling global_to_local."
        assert self.rotation is not None, "Attribute 'rotation' must be set before calling global_to_local."
        assert self.origin is not None, "Attribute 'origin' must be set before calling global_to_local."

        a = self.rotation.T @ ((np.array(x) - self.origin) / np.array(self.zoom))
        # return tuple(a.tolist())
        return tuple(round(float(v), ROUNDING_LVL) for v in a)

    def crop_centroids(self: Self, o_shift: tuple[slice, slice, slice], inplace=False):
        """When you crop an image, you have to also crop the centroids.
        There are actually no boundary to be moved, but the origin must be moved to the new 0,0,0
        Points outside the frame are NOT removed. See NII.compute_crop_slice()

        Args:
            o_shift (tuple[slice, slice, slice]): translation of the origin, cause by the crop
            inplace (bool, optional): inplace. Defaults to True.

        Returns:
            Self
        """
        """Crop the centroids based on the given origin shift due to the image crop.

        When you crop an image, you have to also crop the centroids.
        There are actually no boundaries to be moved, but the origin must be moved to the new 0, 0, 0.
        Points outside the frame are NOT removed. See NII.compute_crop_slice().

        Args:
            o_shift (tuple[slice, slice, slice]): Translation of the origin caused by the crop.
            inplace (bool, optional): If True, perform the operation in-place. Defaults to False.

        Returns:
            Centroids: If inplace is True, returns the modified self. Otherwise, returns a new Centroids object.

        Notes:
            The input 'o_shift' should be a tuple of slices for each dimension, specifying the crop range.
            The 'shape' and 'origin' attributes are updated based on the crop information.
        Raises:
            AttributeError: If the old deprecated format for 'o_shift' (a tuple of floats) is used.

        Examples:
            >>> centroid_obj = Centroids(...)
            >>> crop_slice = (slice(10, 20), slice(5, 15), slice(0, 8))
            >>> new_centroids = centroid_obj.crop_centroids(crop_slice)
        """
        origin = None
        shape = None
        try:
            l = lambda x, y, z: (float(x - o_shift[0].start), float(y - o_shift[1].start), float(z - o_shift[2].start))
            centroids = self.apply_all(l, inplace=inplace)
            if self.shape is not None:
                in_shape = self.shape

                def map_v(sli: slice, i):
                    end = sli.stop
                    if end is None:
                        return in_shape
                    if end >= 0:
                        return end
                    else:
                        return end + in_shape

                shape = tuple(int(map_v(o_shift[i], i) - o_shift[i].start) for i in range(3))
            if self.origin is not None:
                origin = self.local_to_global(tuple(float(y.start) for y in o_shift))
                print(origin)
                # origin = tuple(float(x + y.start) for x, y in zip(self.origin, o_shift))

        except AttributeError:
            warnings.warn(
                "using o_shift with only a tuple of floats is deprecated. Use tuple(slice(start,end),...) instead. end can be None for no change. Input: "
                + str(o_shift)
            )
            o: tuple[float, float, float] = o_shift  # type: ignore

            l = lambda x, y, z: (x - o[0], y - o[1], z - o[2])
            centroids = self.apply_all(l, inplace=inplace)
            shape = None

        if inplace:
            self.shape = shape
            self.origin = origin
            self.centroids = centroids
            return self
        else:
            out = self.copy(centroids=centroids, shape=shape, rotation=self.rotation, origin=origin)
            return out

    def crop_centroids_(self, o_shift: tuple[slice, slice, slice]):
        return self.crop_centroids(o_shift, inplace=True)

    def shift_all_centroid_coordinates(self, translation_vector: tuple[slice, slice, slice] | None, inplace=True, **kwargs):
        if translation_vector is None:
            return self
        return self.crop_centroids(translation_vector, inplace=inplace, **kwargs)

    def reorient(self, axcodes_to: Ax_Codes = ("P", "I", "R"), decimals=ROUNDING_LVL, verbose: logging = False, inplace=False, _shape=None):
        """Reorients the centroids of an image from the current orientation to the specified orientation.

        This method updates the position of the centroids, zoom level, and shape of the image accordingly.

        Args:
            axcodes_to (Ax_Codes, optional): An Ax_Codes object representing the desired orientation of the centroids.
                Defaults to ("P", "I", "R").
            decimals (int, optional): Number of decimal places to round the coordinates of the centroids after reorientation.
                Defaults to ROUNDING_LVL.
            verbose (bool, optional): If True, print a message indicating the current and new orientation of the centroids.
                Defaults to False.
            inplace (bool, optional): If True, update the current centroid object with the reoriented values.
                If False, return a new centroid object with reoriented values. Defaults to False.
            _shape (tuple[int] | None, optional): The shape of the image. Required if the shape is not already present in the centroid object.

        Returns:
            POI: If inplace is True, returns the updated centroid object.
                If inplace is False, returns a new centroid object with reoriented values.

        Raises:
            ValueError: If the given _shape is not compatible with the shape already present in the centroid object.
            AssertionError: If shape is not provided (either in the centroid object or as _shape argument).

        Examples:
            >>> centroid_obj = POI(...)
            >>> new_orientation = ("A", "P", "L")  # Desired orientation for reorientation
            >>> new_centroid_obj = centroid_obj.reorient(axcodes_to=new_orientation, decimals=4, inplace=False)
        """
        ctd_arr = np.transpose(np.asarray(list(self.centroids.values())))
        v_list = list(self.centroids.keys())
        if ctd_arr.shape[0] == 0:
            log.print("No centroids present", verbose=verbose if not isinstance(verbose, bool) else True, type=log_file.Log_Type.WARNING)
            return self

        ornt_fr = nio.axcodes2ornt(self.orientation)  # original centroid orientation
        ornt_to = nio.axcodes2ornt(axcodes_to)

        if (ornt_fr == ornt_to).all():
            log.print("ctd is already rotated to image with ", axcodes_to, verbose=verbose)
            return self
        trans = nio.ornt_transform(ornt_fr, ornt_to).astype(int)
        perm: list[int] = trans[:, 0].tolist()

        if self.shape is not None:
            shape = tuple([self.shape[perm.index(i)] for i in range(len(perm))])

            if _shape != shape and _shape is not None:
                raise ValueError(f"Different shapes {shape} <-> {_shape}, types {type(shape)} <-> {type(_shape)}")
        else:
            shape = _shape
        assert shape is not None, "Require shape information for flipping dimensions. Set self.shape or use reorient_centroids_to"
        shp = np.asarray(shape)
        ctd_arr[perm] = ctd_arr.copy()
        for ax in trans:
            if ax[1] == -1:
                size = shp[ax[0]]
                ctd_arr[ax[0]] = np.around(size - ctd_arr[ax[0]], decimals) - 1
        points = POI_Descriptor()
        ctd_arr = np.transpose(ctd_arr).tolist()
        for v, point in zip(v_list, ctd_arr):
            points[v] = tuple(point)

        log.print("[*] Centroids reoriented from", nio.ornt2axcodes(ornt_fr), "to", axcodes_to, verbose=verbose)
        if self.zoom is not None:
            zoom_i = np.array(self.zoom)
            zoom_i[perm] = zoom_i.copy()
            zoom: Zooms | None = tuple(zoom_i)
        else:
            zoom = None
        perm2 = trans[:, 0]
        flip = trans[:, 1]
        if self.origin is not None and self.shape is not None:
            # When the axis is flipped the origin is changing by that side.
            # flip is -1 when when a side (of shape) is moved from the origin
            # if flip = -1 new local point is affine_matmul_(shape[1]-1) else 0
            change = ((-flip) + 1) / 2  # 1 if flip else 0
            change = tuple(a * s for a, s in zip(change, self.shape))
            origin = self.local_to_global(change)
        else:
            origin = None
        if self.rotation is not None:
            rotation = self.rotation
            rotation *= flip
            rotation[:, perm2] = rotation.copy()
        else:
            rotation = None
        if inplace:
            self.orientation = axcodes_to
            self.centroids = points
            self.zoom = zoom
            self.shape = shape
            self.origin = origin
            self.rotation = rotation
            return self
        return self.copy(orientation=axcodes_to, centroids=points, zoom=zoom, shape=shape, origin=origin, rotation=rotation)

    def reorient_(self, axcodes_to: Ax_Codes = ("P", "I", "R"), decimals=3, verbose: logging = False, _shape=None):
        return self.reorient(axcodes_to, decimals=decimals, verbose=verbose, inplace=True, _shape=_shape)

    def reorient_centroids_to(self, img: Image_Reference, decimals=ROUNDING_LVL, verbose: logging = False, inplace=False) -> Self:
        # reorient centroids to image orientation
        if not isinstance(img, NII):
            img = to_nii(img)
        axcodes_to = nio.aff2axcodes(img.affine)
        return self.reorient(axcodes_to, decimals=decimals, verbose=verbose, inplace=inplace, _shape=img.shape)

    def reorient_centroids_to_(self, img: Image_Reference, decimals=ROUNDING_LVL, verbose: logging = False) -> Self:
        return self.reorient_centroids_to(img, decimals=decimals, verbose=verbose, inplace=True)

    def rescale(self, voxel_spacing=(1, 1, 1), decimals=ROUNDING_LVL, verbose: logging = True, inplace=False) -> Self:
        """Rescale the centroid coordinates to a new voxel spacing in the current x-y-z-orientation.

        Args:
            voxel_spacing (tuple[float, float, float], optional): New voxel spacing in millimeters. Defaults to (1, 1, 1).
            decimals (int, optional): Number of decimal places to round the rescaled coordinates to. Defaults to ROUNDING_LVL.
            verbose (bool, optional): Whether to print a message indicating that the centroid coordinates have been rescaled. Defaults to True.
            inplace (bool, optional): Whether to modify the current instance or return a new instance. Defaults to False.

        Returns:
            POI: If inplace=True, returns the modified POI instance. Otherwise, returns a new POI instance with rescaled centroid coordinates.

        Raises:
            AssertionError: If the 'zoom' attribute is not set in the Centroids instance.

        Examples:
            >>> centroid_obj = POI(...)
            >>> new_voxel_spacing = (2.0, 2.0, 2.0)  # Desired voxel spacing for rescaling
            >>> rescaled_centroid_obj = centroid_obj.rescale(voxel_spacing=new_voxel_spacing, decimals=4, inplace=False)
        """
        assert self.zoom is not None, "This Centroids instance doesn't have a zoom set. Use centroid.zoom = nii.zoom"

        zms = self.zoom
        shp = list(self.shape) if self.shape is not None else None
        ctd_arr = np.transpose(np.asarray(list(self.centroids.values())))
        v_list = list(self.centroids.keys())
        for i in range(3):
            fkt = zms[i] / voxel_spacing[i]
            if len(v_list) != 0:
                ctd_arr[i] = np.around(ctd_arr[i] * fkt, decimals=decimals)
            if shp is not None:
                shp[i] *= fkt
        points = POI_Descriptor()
        ctd_arr = np.transpose(ctd_arr).tolist()
        for v, point in zip(v_list, ctd_arr):
            points[v] = tuple(point)
        log.print("[*] Rescaled centroid coordinates to spacing (x, y, z) =", voxel_spacing, "mm", verbose=verbose)
        if shp is not None:
            shp = tuple(round(float(v), 5) for v in shp)

        if inplace:
            self.centroids = points
            self.zoom = voxel_spacing
            self.shape = shp
            return self
        return self.copy(centroids=points, zoom=voxel_spacing, shape=shp)

    def rescale_(self, voxel_spacing=(1, 1, 1), decimals=3, verbose: logging = False) -> Self:
        return self.rescale(voxel_spacing=voxel_spacing, decimals=decimals, verbose=verbose, inplace=True)

    def map_labels(
        self,
        label_map_full: dict[tuple[int, int], tuple[int, int]] | None = None,
        label_map_region: dict[int | str, int | str] | dict[int, int] = {},
        label_map_subregion: dict[int | str, int | str] | dict[int, int] = {},
        verbose: logging = False,
        inplace=False,
    ) -> Self:
        """
        Maps regions and subregions to new regions and subregions based on a label map dictionary.

        Args:
            label_map_full (dict[tuple[int, int], tuple[int, int]] | None, optional): A dictionary that maps individual points (regions and subregions) to new values. Defaults to None.
            label_map_region (dict[int | str, int | str] | dict[int, int], optional): A dictionary that maps regions to new regions. Defaults to {}.
            label_map_subregion (dict[int | str, int | str] | dict[int, int], optional): A dictionary that maps subregions to new subregions. Defaults to {}.
            verbose (bool, optional): A boolean flag indicating whether to print the label map dictionaries. Defaults to False.
            inplace (bool, optional): A boolean flag indicating whether to modify the centroids in place. Defaults to False.

        Returns:
            Centroids: A new Centroids object with the mapped labels.

        Example Usage:s
            centroid_obj = Centroids(centroids)
            new_centroids = centroid_obj.map_labels(label_map_full = {(20,50):(19,48)}, label_map_region = {10:5}, label_map_subregion = {10:5})

        Outputs:
            Centroids: A new Centroids object with the mapped labels. If `inplace` is True, it modifies the current centroids object in place.
        """
        log.print(label_map_full, "map individual points", verbose=verbose) if label_map_full is not None else None

        if label_map_full is not None:
            if not all([isinstance(a, tuple) for a in label_map_full]):
                raise ValueError(f"{label_map_full} must contain only tuples. Use label_map_subregion or label_map_region instead.")
            poi_new = POI_Descriptor()
            for region, subreg, value in self.items():
                if (region, subreg) in label_map_full:
                    poi_new[label_map_full[(region, subreg)]] = value
                else:
                    poi_new[region:subreg] = value
            gen = poi_new.items()
            new_values = poi_new
        else:
            gen = self.items()
            new_values = None
        label_map_region_ = self.centroids.str_to_int_dict(label_map_region, subregion=False)
        label_map_subregion_ = self.centroids.str_to_int_dict(label_map_subregion, subregion=True)
        log.print(label_map_region_, "map_label regions", verbose=verbose) if len(label_map_region) != 0 else None
        log.print(label_map_subregion_, "map_label subregions", verbose=verbose) if len(label_map_subregion) != 0 else None

        if len(label_map_region) + len(label_map_subregion) != 0:
            poi_new = POI_Descriptor()
            for region, subreg, value in gen:
                if subreg in label_map_subregion_:
                    subreg = label_map_subregion_[subreg]
                if region in label_map_region_:
                    region = label_map_region_[region]
                if subreg == 0 or region == 0:
                    continue
                poi_new[region:subreg] = value
            new_values = poi_new
        if new_values is None:
            return self
        if inplace:
            self.centroids = new_values
            return self
        else:
            return self.copy(centroids=new_values)

    def map_labels_(
        self,
        label_map_full: dict[tuple[int, int], tuple[int, int]] | None = None,
        label_map_region: dict[int | str, int | str] | dict[int, int] = {},
        label_map_subregion: dict[int | str, int | str] | dict[int, int] = {},
        verbose: logging = False,
    ):
        return self.map_labels(
            label_map_full=label_map_full,
            label_map_region=label_map_region,
            label_map_subregion=label_map_subregion,
            verbose=verbose,
            inplace=True,
        )

    def to_global(self):
        """Converts the Centroids object to a global POI_Global object.

        This method converts the local centroid coordinates to global coordinates using the Centroids' zoom,
        rotation, and origin attributes and returns a new POI_Global object.

        Returns:
            POI_Global: A new POI_Global object with the converted global centroid coordinates.

        Examples:
            >>> centroid_obj = Centroids(...)
            >>> global_obj = centroid_obj.to_global()
        """
        import BIDS.core.poi_global as pg

        return pg.POI_Global(self)

    def save(
        self,
        out_path: Path | str,
        make_parents=False,
        additional_info: dict | None = None,
        verbose: logging = True,
        save_hint=2,
    ) -> None:
        """
        Saves the centroids to a JSON file.

        Args:
            out_path (Path | str): The path where the JSON file will be saved.
            make_parents (bool, optional): If True, create any necessary parent directories for the output file.
                Defaults to False.
            verbose (bool, optional): If True, print status messages to the console. Defaults to True.
            save_hint: 0 Default, 1 Gruber, 2 POI (readable), 10 ISO-POI (outdated)
        Returns:
            None

        Raises:
            TypeError: If any of the centroids have an invalid type.

        Example:
            >>> centroids = Centroids(...)
            >>> centroids.save("output/centroids.json")
        """
        if make_parents:
            Path(out_path).parent.mkdir(exist_ok=True, parents=True)

        self.sort()
        # TODO add function here that automatically orders the out_path keys in correct order?
        out_path = str(out_path)
        if len(self.centroids) == 0:
            log.print("Centroids empty, not saved:", out_path, type=log_file.Log_Type.FAIL, verbose=verbose)
            return
        json_object, print_add = _poi_to_dict_list(self, additional_info, save_hint, verbose)

        # Problem with python 3 and int64 serialization.
        def convert(o):
            if isinstance(o, np.integer):
                return int(o)
            if isinstance(o, np.floating):
                return float(o)
            if isinstance(o, np.ndarray):
                return o.tolist()
            raise TypeError(type(o))

        with open(out_path, "w") as f:
            json.dump(json_object, f, default=convert, indent=4)
        log.print(
            "Centroids saved:",
            out_path,
            print_add,
            type=log_file.Log_Type.SAVE,
            verbose=verbose,
        )

    def sort(self, inplace=True, natural_numbers=False):
        """Sort vertebra dictionary by sorting_list"""
        cdt = self.centroids.sort(natural_numbers=natural_numbers, sorting_list=self.sorting_list, inplace=inplace)

        if inplace:
            # self.centroids = cdt
            return self
        return self.copy(centroids=cdt)

    def make_point_cloud_nii(self, affine=None, s=8):
        """Create point cloud NIfTI images from the centroid coordinates.

        This method generates two NIfTI images, one for the regions and another for the subregions,
        representing the point cloud with a specified neighborhood size.

        Args:
            affine (np.ndarray, optional): The affine transformation matrix for the NIfTI image.
                Defaults to None. If None, the centroid object's affine will be used.
            s (int, optional): The neighborhood size. Defaults to 8.

        Returns:
            tuple[NII, NII]: A tuple containing two NII objects representing the point cloud for regions and subregions.

        Raises:
            AssertionError: If the 'shape' or 'zoom' attributes are not set in the Centroids instance.

        Examples:
            >>> centroid_obj = Centroids(...)
            >>> neighborhood_size = 10
            >>> region_cloud, subregion_cloud = centroid_obj.make_point_cloud_nii(s=neighborhood_size)
        """
        assert self.shape is not None, "need shape information"
        assert self.zoom is not None, "need shape information"
        if affine is None:
            affine = self.affine
        arr = np.zeros(self.shape)  # type: ignore
        arr2 = np.zeros(self.shape)  # type: ignore
        s1 = s // 2
        s2 = s - s1
        for region, subregion, (x, y, z) in self.items():
            arr[
                max(int(x - s1 / self.zoom[0]), 0) : min(int(x + s2 / self.zoom[0]), self.shape[0]),
                max(int(y - s1 / self.zoom[1]), 0) : min(int(y + s2 / self.zoom[1]), self.shape[1]),
                max(int(z - s1 / self.zoom[2]), 0) : min(int(z + s2 / self.zoom[2]), self.shape[2]),
            ] = region
            arr2[
                max(int(x - s1 / self.zoom[0]), 0) : min(int(x + s2 / self.zoom[0]), self.shape[0]),
                max(int(y - s1 / self.zoom[1]), 0) : min(int(y + s2 / self.zoom[1]), self.shape[1]),
                max(int(z - s1 / self.zoom[2]), 0) : min(int(z + s2 / self.zoom[2]), self.shape[2]),
            ] = subregion
        nii = nib.Nifti1Image(arr, affine=affine)
        nii2 = nib.Nifti1Image(arr, affine=affine)
        return NII(nii, seg=True), NII(nii2, seg=True)

    def __iter__(self):
        return iter(self.centroids.keys())

    def __contains__(self, key: POI_ID) -> bool:
        return key in self.centroids

    def __getitem__(self, key: POI_ID):
        return self.centroids[key]

    def __setitem__(self, key: POI_ID, value: Tuple[float, float, float]):
        self.centroids[key] = value

    def __len__(self) -> int:
        return self.centroids.__len__()

    def items(self):
        self.sort()
        return self.centroids.items()

    def items_flatten(self):
        self.sort()
        for x1, x2, y in self.centroids.items():
            yield x2 * LABEL_MAX + x1, y

    def keys(self):
        return self.centroids.keys()

    def values(self) -> list[Coordinate]:
        return self.centroids.values()

    def remove_centroid_(self, *label: tuple[int, int]):
        return self.remove_centroid(*label, inplace=True)

    def remove_centroid(self, *label: tuple[int, int], inplace=False):
        obj: POI = self.copy() if inplace == False else self
        for l in label:
            if isinstance(l, Location):
                l = l.value
            obj.centroids.pop(l, None)
        return obj

    def round(self, ndigits, inplace=False):
        """Round the centroid coordinates to a specified number of digits.

        This method rounds the x, y, and z coordinates of all centroids to the given number of digits.

        Args:
            ndigits (int): The number of digits to round to.
            inplace (bool, optional): If True, modify the centroid object in place.
                If False, return a new centroid object with rounded coordinates. Defaults to False.

        Returns:
            Centroids: If inplace=True, returns the modified Centroids instance.
                Otherwise, returns a new Centroids instance with rounded coordinates.

        Examples:
            >>> centroid_obj = Centroids(...)
            >>> num_digits = 3
            >>> rounded_centroid_obj = centroid_obj.round(ndigits=num_digits, inplace=False)
        """
        out = POI_Descriptor()
        for re, sre, (x, y, z) in self.items():
            out[re:sre] = (round(x, ndigits=ndigits), round(y, ndigits=ndigits), round(z, ndigits=ndigits))
        if inplace:
            self.centroids = out
            return self
        return self.copy(out)

    def round_(self, ndigits):
        return self.round(ndigits=ndigits, inplace=True)

    def calculate_distances(self, target_point: Tuple[float, float, float]) -> Dict[Tuple[int, int], float]:
        """Calculate the distances between the target point and each centroid.

        Args:
            target_point (Tuple[float, float, float]): The target point represented as a tuple of x, y, and z coordinates.

        Returns:
            Dict[Tuple[int, int], float]: A dictionary containing the distances between the target point and each centroid.
            The keys are tuples of two integers representing the region and subregion labels of the centroids,
            and the values are the distances (in millimeters) between the target point and each centroid.
        """
        distances = {}
        for region, subregion, (x, y, z) in self.centroids.items():
            distance = ((target_point[0] - x) ** 2 + (target_point[1] - y) ** 2 + (target_point[2] - z) ** 2) ** 0.5
            distances[(region, subregion)] = distance
        return distances

    def filter_points_inside_shape(self, inplace=False) -> Self:
        """Filter out centroid points that are outside the defined shape.

        This method checks each centroid point and removes any point whose coordinates
        are outside the defined shape.

        Returns:
            POI: A new POI object containing centroid points that are inside the defined shape.

        Examples:
            >>> centroid_obj = POI(...)
            >>> filtered_centroids = centroid_obj.filter_points_inside_shape()
        """
        if self.shape is None:
            raise ValueError("Cannot filter points outside shape as the shape attribute is not defined.")

        filtered_centroids = POI_Descriptor()
        for region, subregion, (x, y, z) in self.centroids.items():
            if 0 <= x < self.shape[0] and 0 <= y < self.shape[1] and 0 <= z < self.shape[2]:
                filtered_centroids[(region, subregion)] = (x, y, z)
        if inplace:
            self.centroids = filtered_centroids
            return self
        return self.copy(filtered_centroids)

    @classmethod
    def load(cls, poi: Centroid_Reference):
        """Load a Centroids object from various input sources.

        This method provides a convenient way to load a Centroids object from different sources,
        including BIDS files, file paths, image references, or existing POI objects.

        Args:
            poi (Centroid_Reference): The input source from which to load the Centroids object.
                It can be one of the following types:
                - BIDS_FILE: A BIDS file representing the Centroids object.
                - Path: The path to the file containing the Centroids object.
                - str: The string representation of the Centroids object file path.
                - Tuple[Image_Reference, Image_Reference, list[int]]: A tuple containing two Image_Reference objects
                and a list of integers representing the centroid data.
                - POI: An existing POI object to be loaded.

        Returns:
            POI: The loaded Centroids object.

        Examples:
            >>> # Load from a BIDS file
            >>> bids_file_path = BIDS_FILE("/path/to/centroids.json", "/path/to/dataset/")
            >>> loaded_poi = POI.load(bids_file_path)

            >>> # Load from a file path
            >>> file_path = "/path/to/centroids.json"
            >>> loaded_poi = POI.load(file_path)

            >>> # Load from an image reference tuple and centroid data
            >>> image_ref1 = Image_Reference(...)
            >>> image_ref2 = Image_Reference(...)
            >>> centroid_data = [1, 2, 3]
            >>> loaded_poi = POI.load((image_ref1, image_ref2, centroid_data))

            >>> # Load from an existing POI object
            >>> existing_poi = POI(...)
            >>> loaded_poi = POI.load(existing_poi)
        """
        return load_poi(poi)

    def assert_affine(self, nii: NII | Self):
        assert self.zoom is not None
        assert nii.zoom is not None
        assert np.isclose(self.zoom, nii.zoom, rtol=0.001).all()
        assert self.orientation == nii.orientation, (self.orientation, nii.orientation)
        s = self.shape
        if isinstance(nii, NII):
            assert s is not None
            s = tuple(round(x, 0) for x in s)
        assert s == nii.shape, (self, str(nii))
        assert self.rotation is not None
        assert nii.rotation is not None
        assert self.rotation is not None
        assert nii.rotation is not None
        assert np.isclose(self.rotation, nii.rotation).all()
        assert self.origin is not None
        assert nii.origin is not None
        assert nii.origin is not None
        assert self.origin is not None
        assert np.isclose(self.origin, nii.origin).all()
        aff_equ = np.isclose(self.affine, nii.affine, atol=1e-6).all()
        assert aff_equ, f"{self.affine}\n {nii.affine}"


###### SORTING #####
def order_vert_name(elem: tuple[int, Any], v_idx_order: list[int], mod=LABEL_MAX):
    idx = elem[0] % mod
    off = elem[0] // mod
    assert idx in v_idx_order, f"{elem[0]} {idx} - {off} not in v_name2idx, only got {v_idx_order},{idx == v_idx_order[0]}"
    return v_idx_order.index(idx) + off


class VertebraCentroids(POI):
    def __init__(self, _centroids, _orientation: Ax_Codes, _shape: tuple[float, float, float] | None, zoom=None, **qargs):
        assert isinstance(_orientation, (tuple, list)), "_orientation is not a list or a tuple. Did you swap _centroids and _orientation"
        super().__init__(orientation=_orientation, centroids=_centroids, shape=_shape, zoom=zoom, sorting_list=v_idx_order.copy(), **qargs)
        self.sort()

    @classmethod
    def from_centroids(cls, ctd: POI):
        a = ctd.centroids.copy()
        a = {(k, k2): v for k, k2, v in a.items() if k <= 30}  # filter all non Vertebra_Centroids
        return cls(
            a, ctd.orientation, _shape=ctd.shape, zoom=ctd.zoom, rotation=ctd.rotation, origin=ctd.origin, format=ctd.format, info=ctd.info
        )

    def get_xth_vertebra(self, index: int, subreg_id=50):
        """

        Args:
            index:

        Returns:
            the <index>-th vertebra in this Centroid list (if index == -1, returns the last one)
        """
        self.sort()
        centroid_keys = [k for k, k2 in list(self.keys()) if subreg_id == k2]
        if index == -1:
            return self.centroids[centroid_keys[len(self.centroids) - 1] : subreg_id]
        return self.centroids[centroid_keys[index] : subreg_id]

    def get_last_l_centroid(self, subreg_id=50):
        """

        Returns:
            The last L centroid coordinates. None if not found
        """
        # Can only be L6, L5, or L4
        centroid_keys = [k for k, k2 in list(self.keys()) if subreg_id == k2]

        idx = 25 if 25 in centroid_keys else 24 if 24 in centroid_keys else 23 if 23 in centroid_keys else None
        if idx is not None:
            return idx, self.centroids[idx:subreg_id]
        return None, None


######## Saving #######
def _is_Point3D(obj) -> TypeGuard[_Point3D]:
    return "label" in obj and "X" in obj and "Y" in obj and "Z" in obj


FORMAT_DOCKER = 0
FORMAT_GRUBER = 1
FORMAT_POI = 2
FORMAT_OLD_POI = 10
format_key = {FORMAT_DOCKER: "docker", FORMAT_GRUBER: "guber", FORMAT_POI: "POI"}
format_key2value = {value: key for key, value in format_key.items()}


def _poi_to_dict_list(ctd: POI, additional_info: dict | None, save_hint=0, verbose: logging = False):
    ori: _Orientation = {"direction": ctd.orientation}
    print_out = ""
    # if hasattr(ctd, "location") and ctd.location != Location.Unknown:
    #    ori["location"] = ctd.location_str  # type: ignore
    if ctd.zoom is not None:
        ori["zoom"] = ctd.zoom  # type: ignore
    if ctd.origin is not None:
        ori["origin"] = ctd.origin  # type: ignore
    if ctd.rotation is not None:
        ori["rotation"] = ctd.rotation  # type: ignore
    if ctd.shape is not None:
        ori["shape"] = ctd.shape  # type: ignore
    if save_hint in format_key:
        ori["format"] = format_key[save_hint]  # type: ignore
        print_out = "in format " + format_key[save_hint]

    if additional_info is not None:
        for k, v in additional_info.items():
            if k not in ori:
                ori[k] = v

    for k, v in ctd.info.items():
        if k not in ori:
            ori[k] = v

    dict_list: list[Union[_Orientation, _Point3D | dict]] = [ori]

    if save_hint == FORMAT_OLD_POI:
        ctd = ctd.rescale((1, 1, 1), verbose=verbose).reorient_(("R", "P", "I"), verbose=verbose)
        dict_list = []

    temp_dict = {}
    ctd.sort(natural_numbers=True) if ctd.sorting_list is not None else ctd.sort()
    for vert_id, subreg_id, (x, y, z) in ctd.items():
        if save_hint == FORMAT_DOCKER:
            dict_list.append({"label": subreg_id * LABEL_MAX + vert_id, "X": x, "Y": y, "Z": z})
        elif save_hint == FORMAT_GRUBER:
            v = v_idx2name[vert_id].replace("T", "TH") + "_" + conversion_poi2text[subreg_id]
            dict_list.append({"label": v, "X": x, "Y": y, "Z": z})
        elif save_hint == FORMAT_POI:
            v_name = v_idx2name[vert_id] if vert_id in v_idx2name else str(vert_id)
            # sub_name = v_idx2name[subreg_id]
            if v_name not in temp_dict:
                temp_dict[v_name] = {}
            temp_dict[v_name][subreg_id] = (x, y, z)
        elif save_hint == FORMAT_OLD_POI:
            if vert_id not in temp_dict:
                temp_dict[vert_id] = {}
            temp_dict[vert_id][str(subreg_id)] = str((float(x), float(y), float(z)))
        else:
            raise NotImplementedError(save_hint)
    if len(temp_dict) != 0:
        if save_hint == FORMAT_OLD_POI:
            for k, v in temp_dict.items():
                out_dict = {"vert_label": str(k), **v}
                dict_list.append(out_dict)
        else:
            dict_list.append(temp_dict)
    return dict_list, print_out


######### Load #############
# Handling centroids #


def load_poi(ctd_path: Centroid_Reference, verbose=True) -> POI:
    """
    Load centroids from a file or a BIDS file object.

    Args:
        ctd_path (Centroid_Reference): Path to a file or BIDS file object from which to load centroids.
            Alternatively, it can be a tuple containing the following items:
            - vert: str, the name of the vertebra.
            - subreg: str, the name of the subregion.
            - ids: list[int | Location], a list of integers and/or Location objects used to filter the centroids.

    Returns:
        A Centroids object containing the loaded centroids.

    Raises:
        AssertionError: If `ctd_path` is not a recognized type.

    """
    if isinstance(ctd_path, POI):
        return ctd_path
    elif isinstance(ctd_path, BIDS.bids_files.BIDS_FILE):
        dict_list: _Centroid_DictList = ctd_path.open_json()  # type: ignore
    elif isinstance(ctd_path, str) or isinstance(ctd_path, Path):
        with open(ctd_path) as json_data:
            dict_list: _Centroid_DictList = json.load(json_data)
            json_data.close()
    elif isinstance(ctd_path, tuple):
        vert = ctd_path[0]
        subreg = ctd_path[1]
        ids: list[int | Location] = ctd_path[2]  # type: ignore
        return calc_centroids_from_subreg_vert(vert, subreg, subreg_id=ids)
    else:
        assert False, f"{type(ctd_path)}\n{ctd_path}"
    ### format_POI_old has no META header
    if "direction" not in dict_list[0] and "vert_label" in dict_list[0]:
        return _load_format_POI_old(dict_list)  # This file if used in the old POI-pipeline and is deprecated

    assert "direction" in dict_list[0], f'File format error: first index must be a "Direction" but got {dict_list[0]}'
    axcode: Ax_Codes = tuple(dict_list[0]["direction"])  # type: ignore
    zoom: Zooms = dict_list[0].get("zoom", None)  # type: ignore
    shape = dict_list[0].get("shape", None)  # type: ignore
    shape = tuple(shape) if shape is not None else None
    format = dict_list[0].get("format", None)
    origin = dict_list[0].get("origin", None)
    origin = tuple(origin) if origin is not None else None
    rotation = dict_list[0].get("rotation", None)
    info = {}
    for k, v in dict_list[0].items():
        if k not in ctd_info_blacklist:
            info[k] = v

    format = format_key2value[format] if format is not None else None
    centroids = POI_Descriptor()
    if format is None or format == FORMAT_DOCKER or format == FORMAT_GRUBER:
        _load_docker_centroids(dict_list, centroids, format)
    elif format == FORMAT_POI:
        _load_POI_centroids(dict_list, centroids)
    else:
        raise NotImplementedError(format)
    return POI(centroids, orientation=axcode, zoom=zoom, shape=shape, format=format, info=info, origin=origin, rotation=rotation)


def _load_docker_centroids(dict_list, centroids: POI_Descriptor, format):
    for d in dict_list[1:]:
        assert "direction" not in d, f'File format error: only first index can be a "direction" but got {dict_list[0]}'
        if "nan" in str(d):  # skipping NaN centroids
            continue
        elif _is_Point3D(d):
            try:
                a = int(d["label"])
                centroids[a % LABEL_MAX, a // LABEL_MAX] = (d["X"], d["Y"], d["Z"])
            except Exception:
                try:
                    number, subreg = str(d["label"]).split("_", maxsplit=1)
                    number = number.replace("TH", "T").replace("SA", "S1")
                    vert_id = v_name2idx[number]
                    subreg_id = conversion_poi[subreg]
                    centroids[vert_id, subreg_id] = (d["X"], d["Y"], d["Z"])
                except:
                    print(f'Label {d["label"]} is not an integer and cannot be converted to an int')
                    centroids[d["label"]] = (d["X"], d["Y"], d["Z"])
        else:
            raise ValueError(d)


def _load_format_POI_old(dict_list):
    # [
    # {
    #    "vert_label": "8",
    #    "85": "(281, 185, 274)",
    #    ...
    # }{...}
    # ...
    # ]
    centroids = POI_Descriptor()
    for d in dict_list:
        d: dict[str, str]
        vert_id = int(d["vert_label"])
        for k, v in d.items():
            if k == "vert_label":
                continue
            sub_id = int(k)
            t = v.replace("(", "").replace(")", "").replace(" ", "").split(",")
            t = tuple(float(x) for x in t)
            centroids[vert_id, sub_id] = t
    return POI(centroids, orientation=("R", "P", "I"), zoom=(1, 1, 1), shape=None, format=FORMAT_OLD_POI)


def _to_int(vert_id):
    try:
        return int(vert_id)
    except Exception:
        return v_name2idx[vert_id]


def _load_POI_centroids(dict_list, centroids: POI_Descriptor):
    assert len(dict_list) == 2
    d: dict[int | str, dict[int | str, tuple[float, float, float]]] = dict_list[1]
    for vert_id, v in d.items():
        vert_id = _to_int(vert_id)
        for sub_id, t in v.items():
            sub_id = _to_int(sub_id)
            centroids[vert_id, sub_id] = tuple(t)


def loc2int(i: int | Location):
    if isinstance(i, int):
        return i
    return i.value


def int2loc(i: int | Location | list[int | Location]):
    if isinstance(i, List):
        return [int2loc(j) for j in i]
    elif isinstance(i, int):
        try:
            return Location(i)
        except Exception:
            return i
    return i


def calc_centroids_labeled_buffered(
    msk_reference: Image_Reference,
    subreg_reference: Image_Reference | None,
    out_path: Path | str,
    subreg_id: int | Location | list[int | Location] = 50,
    verbose=True,
    override=False,
    decimals=3,
    # additional_folder=False,
    check_every_point=True,
    use_vertebra_special_action=True,
) -> POI:
    """
    Computes the centroids of the given mask `msk_reference` with respect to the given subregion `subreg_reference`,
    and saves them to a file at `out_path` (if `override=False` and the file already exists, the function loads and returns
    the existing centroids from the file).

    If `out_path` is None and `msk_reference` is a `BIDS.bids_files.BIDS_FILE` object, the function generates a path to
    save the centroids file based on the `label` attribute of the file and the given `subreg_id`.

    If `subreg_reference` is None, the function computes the centroids using only `msk_reference`.

    If `subreg_reference` is not None, the function computes the centroids with respect to the given `subreg_id` in the
    subregion defined by `subreg_reference`.

    Args:
        msk_reference (Image_Reference): The mask to compute the centroids from.
        subreg_reference (Image_Reference | None, optional): The subregion mask to compute the centroids relative to.
        out_path (Path | None, optional): The path to save the computed centroids to.
        subreg_id (int | Location | list[int | Location], optional): The ID of the subregion to compute centroids in.
        verbose (bool, optional): Whether to print verbose output during the computation.
        override (bool, optional): Whether to overwrite any existing centroids file at `out_path`.
        decimals (int, optional): The number of decimal places to round the computed centroid coordinates to.
        additional_folder (bool, optional): Whether to add a `/ctd/` folder to the path generated for the output file.

    Returns:
        Centroids: The computed centroids, as a `Centroids` object.
    """
    assert out_path is not None, "Automatic path generation is deprecated"
    out_path = Path(out_path)
    # assert out_path is not None or isinstance(
    #    msk_reference, BIDS.bids_files.BIDS_FILE
    # ), "Automatic path generation is only possible with a BIDS_FILE"
    # if out_path is None and isinstance(msk_reference, BIDS.bids_files.BIDS_FILE):
    #    if not isinstance(subreg_id, list) and subreg_id != -1:
    #        name = subreg_idx2name[loc2int(subreg_id)]
    #    elif subreg_reference is None:
    #        name = msk_reference.get("label", default="full")
    #    else:
    #        name = "multi"
    #    assert name is not None
    #    out_path = msk_reference.get_changed_path(
    #        file_type="json",
    #        format="ctd",
    #        info={"label": name.replace("_", "-")},
    #        parent="derivatives" if msk_reference.get_parent() == "rawdata" else msk_reference.get_parent(),
    #        additional_folder="ctd" if additional_folder else None,
    #    )
    assert out_path is not None
    if override:
        out_path.unlink()
    log.print(f"[*] Generate ctd json towards {out_path}", verbose=verbose)

    msk_nii = to_nii(msk_reference, True)
    sub_nii = to_nii_optional(subreg_reference, True)
    if sub_nii is None or not check_every_point:
        if out_path.exists():
            return POI.load(out_path)
    if sub_nii is not None:
        ctd = calc_centroids_from_subreg_vert(
            msk_nii,
            sub_nii,
            buffer_file=out_path,
            decimals=decimals,
            subreg_id=subreg_id,
            verbose=verbose,
            use_vertebra_special_action=use_vertebra_special_action,
        )
    else:
        assert not isinstance(subreg_id, list)
        ctd = calc_centroids(msk_nii, subreg_id=loc2int(subreg_id), decimals=decimals)

    ctd.save(out_path, verbose=verbose)
    return ctd


def calc_centroids_from_subreg_vert(
    vert_msk: Image_Reference,
    subreg: Image_Reference,
    buffer_file: str | Path | None = None,
    save_buffer_file=False,
    decimals=2,
    subreg_id: int | Location | list[int | Location] = 50,
    axcodes_to: Ax_Codes | None = None,
    verbose: logging = True,
    extend_to: POI | None = None,
    use_vertebra_special_action=True,
) -> POI:
    """
    Calculates the centroids of a subregion within a vertebral mask.

    Args:
        vert_msk (Image_Reference): A vertebral mask image reference.
        subreg (Image_Reference): An image reference for the subregion of interest.
        decimals (int, optional): Number of decimal places to round the output coordinates to. Defaults to 1.
        subreg_id (int | Location | list[int | Location], optional): The ID(s) of the subregion(s) to calculate centroids for. Defaults to 50.
        axcodes_to (Ax_Codes | None, optional): A tuple of axis codes indicating the target orientation of the images. Defaults to None.
        verbose (bool, optional): Whether to print progress messages. Defaults to False.
        fixed_offset (int, optional): A fixed offset value to add to the calculated centroid coordinates. Defaults to 0.
        extend_to (POI | None, optional): An existing POI object to extend with the new centroid values. Defaults to None.

    Returns:
        POI: A POI object containing the calculated centroid coordinates.
    """
    if buffer_file is not None and Path(buffer_file).exists():
        assert extend_to is None
        extend_to = POI.load(buffer_file)

    vert_msk = to_nii(vert_msk, seg=True)
    subreg_msk = to_nii(subreg, seg=True)
    log.print("[*] Calc centroids from subregion id", int2loc(subreg_id), vert_msk.shape, verbose=verbose)

    if axcodes_to is not None:
        # Like: ("P","I","R")
        vert_msk = vert_msk.reorient(verbose=verbose, axcodes_to=axcodes_to, inplace=False)
        subreg_msk = subreg_msk.reorient(verbose=verbose, axcodes_to=axcodes_to, inplace=False)
    assert vert_msk.orientation == subreg_msk.orientation
    # Recursive call for multiple subregion ids
    if isinstance(subreg_id, list):
        poi = POI({}, orientation=vert_msk.orientation, **vert_msk._extract_affine(), format=FORMAT_POI)
        print("list") if verbose else None
        for id in subreg_id:
            poi = calc_centroids_from_subreg_vert(
                vert_msk, subreg_msk, buffer_file=None, subreg_id=loc2int(id), verbose=verbose, extend_to=poi, decimals=decimals
            )
        return poi
    # Prepare mask to binary mask
    vert_arr = vert_msk.get_seg_array()
    subreg_msk = subreg_msk.get_seg_array()
    assert subreg_msk.shape == vert_arr.shape, "Shape miss-match" + str(subreg_msk.shape) + str(vert.shape)
    subreg_id = loc2int(subreg_id)
    if use_vertebra_special_action:
        mapping_vert = {
            Location.Vertebra_Disc.value: 100,
            Location.Vertebral_Body_Endplate_Superior.value: 200,
            Location.Vertebral_Body_Endplate_Inferior.value: 300,
        }
        if subreg_id == Location.Vertebra_Corpus.value:
            subreg_msk[subreg_msk == 49] = Location.Vertebra_Corpus.value
        elif subreg_id == Location.Vertebra_Full.value:
            subreg_msk[subreg_msk != 0] = Location.Vertebra_Full.value

        if subreg_id in mapping_vert.keys():  # IVD / Endplates Superior / Endplate Inferior
            vert_arr[subreg_msk <= mapping_vert[subreg_id]] = 0
            vert_arr[subreg_msk >= mapping_vert[subreg_id] + 100] = 0
            vert_arr -= mapping_vert[subreg_id]
        else:
            vert_arr[subreg_msk >= 100] = 0
            if subreg_id < 40 or subreg_id > 50:
                raise NotImplementedError(
                    f"POI of subreg {subreg_id} - {Location(subreg_id) if subreg_id in Location else 'undefined'} is not a centroid. If you want the general Centroid computation use use_vertebra_special_action = False"
                )

    vert_arr[subreg_msk != subreg_id] = 0
    msk_data = vert_arr
    if extend_to is not None and subreg_id in extend_to.centroids.keys_subregion():
        missing = False
        for reg in np.unique(vert_arr):
            if reg == 0:
                continue
            if (reg, subreg_id) in extend_to:
                continue
            missing = True
            break
        if not missing:
            return extend_to

    nii = nib.nifti1.Nifti1Image(msk_data, vert_msk.affine, vert_msk.header)
    poi = calc_centroids(nii, decimals=decimals, subreg_id=subreg_id, extend_to=extend_to)
    if save_buffer_file:
        assert buffer_file is not None
        poi.save(buffer_file)
    return poi


def calc_centroids(msk: Image_Reference, decimals=3, vert_id=-1, subreg_id=50, extend_to: POI | None = None) -> POI:
    """
    Calculates the centroid coordinates of each region in the given mask image.

    Args:
        msk (Image_Reference): An `Image_Reference` object representing the input mask image.
        decimals (int, optional): An optional integer specifying the number of decimal places to round the centroid coordinates to (default is 3).
        vert_id (int, optional): An optional integer specifying the fixed vertical dimension for the centroids (default is -1).
        subreg_id (int, optional): An optional integer specifying the fixed subregion dimension for the centroids (default is 50).
        extend_to (POI, optional): An optional `POI` object to add the calculated centroids to (default is None).

    Returns:
        POI: A `POI` object containing the calculated centroid coordinates.

    Raises:
        AssertionError: If the `extend_to` object has a different orientation, location, or zoom than the input mask.

    Notes:
        - The function calculates the centroid coordinates of each region in the mask image.
        - The centroid coordinates are rounded to the specified number of decimal places.
        - The fixed dimensions for the centroids can be specified using `vert_id` and `subreg_id`.
        - If `extend_to` is provided, the calculated centroids will be added to the existing object and the updated object will be returned.
        - The region label is assumed to be an integer.
        - NaN values in the binary mask are ignored.
    """
    assert vert_id == -1 or subreg_id == -1, "first or second dimension must be fixed."
    msk = to_nii(msk, seg=True)
    msk_data = msk.get_seg_array()
    axc = nio.aff2axcodes(msk.affine)
    if extend_to is None:
        ctd_list = POI_Descriptor()
    else:
        ctd_list = extend_to.centroids.copy()
        extend_to.assert_affine(msk)
    for i in msk.unique():
        msk_temp = np.zeros(msk_data.shape, dtype=bool)
        msk_temp[msk_data == i] = True
        ctr_mass: list[float] = center_of_mass(msk_temp)  # type: ignore
        if subreg_id == -1:
            ctd_list[vert_id, int(i)] = tuple([round(x, decimals) for x in ctr_mass])
        else:
            ctd_list[int(i), subreg_id] = tuple([round(x, decimals) for x in ctr_mass])
    return POI(ctd_list, orientation=axc, **msk._extract_affine())
