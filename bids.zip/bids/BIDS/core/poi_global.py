from typing import Dict, Tuple, Union
from dataclasses import dataclass, field

import numpy as np
from BIDS.core import poi
from BIDS import Image_Reference, Centroid_Reference, to_nii, NII

Centroid_Dict = poi.Centroid_Dict

import nibabel.orientations as nio

###### GLOBAL POI #####


class POI_Global:
    """
    Represents a global Point of Interest (POI) in a coordinate system.
    Inherits from the `Abstract_POI` class and contains methods for converting the POI to different coordinate systems.
    """

    def __init__(self, local_poi: poi.POI):
        self.local_poi = local_poi
        self._centroids = None

    @property
    def is_global(self) -> bool:
        """
        Check if the POI is global.

        Returns:
            bool: True if the POI is global, False otherwise.
        """
        return True

    @property
    def centroids(self):
        """
        Get the centroids of the POI.

        Returns:
            dict: A dictionary containing the global centroids of the POI.
        """
        if self._centroids is None:
            global_points = poi.POI_Descriptor(definition=self.local_poi.centroids.definition)
            for k1, k2, v in self.local_poi.items():
                global_points[k1:k2] = self.local_poi.local_to_global(v)
            self._centroids = global_points
        return self._centroids

    def to_other_nii(self, ref: poi.Image_Reference) -> Union[poi.POI, poi.NII]:
        """
        Convert the POI to another NII file.

        Args:
            ref (poi.Image_Reference): The reference to the NII file.

        Returns:
            Union[poi.POI, poi.NII]: The converted POI as either a POI or NII object.
        """
        return self.to_other(poi.to_nii(ref))

    def to_other_poi(self, ref: poi.Centroid_Reference) -> poi.POI:
        """
        Convert the POI to another POI.

        Args:
            ref (poi.Centroid_Reference): The reference to the other POI.

        Returns:
            poi.POI: The converted POI.
        """
        return self.to_other(poi.POI.load(ref))

    def to_other(self, msk: Union[poi.POI, poi.NII]) -> poi.POI:
        """
        Convert the POI to another coordinate system.

        Args:
            msk (Union[poi.POI, poi.NII]): The reference to the other coordinate system.

        Returns:
            poi.POI: The converted POI.
        """
        out = poi.POI_Descriptor(definition=self.local_poi.centroids.definition)
        for k1, k2, v in self.centroids.items():
            v_out = msk.global_to_local(v)
            v_out = np.round(v_out, 7)
            v_out = tuple(v_out.tolist())
            out[k1, k2] = v_out
        return poi.POI(
            centroids=out,
            orientation=nio.ornt2axcodes(nio.io_orientation(msk.affine)),
            **msk._extract_affine(),
            sorting_list=self.local_poi.sorting_list,
            info=self.local_poi.info,
            format=self.local_poi.format,
        )
